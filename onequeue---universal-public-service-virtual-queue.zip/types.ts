
export enum ServiceType {
  HOSPITAL = 'Hospital',
  OFFICE = 'Public Office',
  RATION = 'Ration Shop',
  UTILITY = 'Utility Center'
}

export enum TokenStatus {
  WAITING = 'Waiting',
  CALLING = 'Now Serving',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled',
  PAUSED = 'Paused'
}

export type SyncStatus = 'synced' | 'pending' | 'failed';

export interface User {
  id: string;
  username: string;
  fullName: string;
  avatar?: string;
  email?: string;
  isBiometricEnabled: boolean;
  role: 'citizen' | 'staff' | 'admin';
  isVerified: boolean;
  employeeId?: string;
  workLocationId?: string; // Links staff to a specific hospital/ration shop
}

export interface Token {
  id: string;
  locationId: string; 
  number: number;
  prefix: string;
  name: string;
  phone?: string;
  isWalkIn: boolean;
  status: TokenStatus;
  timestamp: Date;
  estimatedWaitTime: number; 
  syncStatus: SyncStatus;
  notificationMethod: 'none' | 'sms';
  calledAt?: Date;
  completedAt?: Date;
}

export interface ServiceLocation {
  id: string;
  name: string;
  type: ServiceType;
  address: string;
  city?: string;
  state?: string;
  pincode?: string;
  currentQueueSize: number;
  averageServiceTime: number; 
  isActive: boolean;
  isPaused: boolean;
  mapUri?: string;
  openingTime?: string; // e.g., "08:00"
  closingTime?: string; // e.g., "20:00"
}

export interface SMSMessage {
  id: string;
  to: string;
  content: string;
  timestamp: Date;
  status: 'sent' | 'delivered' | 'failed';
  tokenNumber: string;
}
