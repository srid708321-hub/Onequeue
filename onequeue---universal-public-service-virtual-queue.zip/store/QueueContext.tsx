
import React, { createContext, useContext, useState, useCallback, useEffect, useMemo } from 'react';
import { Token, TokenStatus, ServiceLocation, ServiceType, SyncStatus, SMSMessage, User } from '../types';
import { translations, Language } from './translations';
import { GoogleGenAI, Modality } from '@google/genai';

export type VoiceName = 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';

interface QueueContextType {
  tokens: Token[];
  locations: ServiceLocation[];
  smsLog: SMSMessage[];
  recentlyViewedIds: string[];
  currentRole: 'citizen' | 'staff' | 'display' | null;
  selectedLocationId: string | null;
  language: Language;
  selectedVoice: VoiceName;
  isVoiceEnabled: boolean;
  isOnline: boolean;
  isSyncing: boolean;
  isTrainingMode: boolean;
  isSupportOpen: boolean;
  setIsSupportOpen: (val: boolean) => void;
  currentUser: User | null;
  setIsTrainingMode: (val: boolean) => void;
  setRole: (role: 'citizen' | 'staff' | 'display') => void;
  setLocation: (id: string | null) => void;
  addFoundLocation: (loc: ServiceLocation) => void;
  addToRecentlyViewed: (id: string) => void;
  setLanguage: (lang: Language) => void;
  setVoice: (voice: VoiceName) => void;
  setVoiceEnabled: (enabled: boolean) => void;
  t: (key: keyof typeof translations['en'], params?: Record<string, string | number>) => string;
  addToken: (name: string, locationId: string, phone?: string, isWalkIn?: boolean, notifySms?: boolean) => void;
  callNext: () => void;
  pauseQueue: () => void;
  cancelToken: (id: string) => void;
  activeToken: Token | null;
  isLocationOpen: (loc: ServiceLocation) => boolean;
  clearSMSLog: () => void;
  resetTraining: () => void;
  login: (user: User) => void;
  logout: () => void;
  updateUserBiometrics: (enabled: boolean) => void;
  updateUserProfile: (updates: Partial<User>) => void;
  getPeopleAhead: (tokenId: string) => number;
  getEstimatedWait: (tokenId: string) => number;
  speakNotification: (text: string) => Promise<void>;
  syncPendingTokens: () => Promise<void>;
}

const QueueContext = createContext<QueueContextType | undefined>(undefined);

const INITIAL_LOCATIONS: ServiceLocation[] = [
  { id: 'loc-1', name: 'District General Hospital', type: ServiceType.HOSPITAL, address: 'Civil Lines Road', city: 'Delhi', state: 'Delhi', pincode: '110001', currentQueueSize: 0, averageServiceTime: 12, isActive: true, isPaused: false, openingTime: "00:00", closingTime: "23:59" },
  { id: 'loc-2', name: 'Fair Price Ration Shop #12', type: ServiceType.RATION, address: 'Market Block A', city: 'Mumbai', state: 'Maharashtra', pincode: '400001', currentQueueSize: 0, averageServiceTime: 5, isActive: true, isPaused: false, openingTime: "09:00", closingTime: "18:00" },
];

const MOCK_TOKENS: (locId: string) => Token[] = (locId) => [
  { id: 'mock-1', locationId: locId, number: 1, prefix: 'T', name: 'Amit Kumar', status: TokenStatus.WAITING, timestamp: new Date(Date.now() - 500000), estimatedWaitTime: 10, syncStatus: 'synced', isWalkIn: false, notificationMethod: 'none' },
  { id: 'mock-2', locationId: locId, number: 2, prefix: 'T', name: 'Sita Devi', status: TokenStatus.WAITING, timestamp: new Date(Date.now() - 400000), estimatedWaitTime: 20, syncStatus: 'synced', isWalkIn: false, notificationMethod: 'none' },
  { id: 'mock-3', locationId: locId, number: 3, prefix: 'T', name: 'John Doe', status: TokenStatus.WAITING, timestamp: new Date(Date.now() - 300000), estimatedWaitTime: 30, syncStatus: 'synced', isWalkIn: false, notificationMethod: 'none' },
];

const TOKENS_STORAGE_KEY = 'onequeue_user_tokens';
const SMS_LOG_STORAGE_KEY = 'onequeue_sms_log';
const USER_STORAGE_KEY = 'onequeue_current_user';
const RECENT_LOCS_KEY = 'onequeue_recent_locs';
const VOICE_STORAGE_KEY = 'onequeue_pref_voice';
const VOICE_ENABLED_KEY = 'onequeue_voice_enabled';
const LOCATIONS_STORAGE_KEY = 'onequeue_saved_locations';

function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const QueueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(USER_STORAGE_KEY);
    return saved ? JSON.parse(saved) : null;
  });
  const [tokens, setTokens] = useState<Token[]>(() => {
    const saved = localStorage.getItem(TOKENS_STORAGE_KEY);
    return saved ? JSON.parse(saved).map((t: any) => ({ 
      ...t, 
      timestamp: new Date(t.timestamp),
      calledAt: t.calledAt ? new Date(t.calledAt) : undefined,
      completedAt: t.completedAt ? new Date(t.completedAt) : undefined
    })) : [];
  });
  const [recentlyViewedIds, setRecentlyViewedIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(RECENT_LOCS_KEY);
    return saved ? JSON.parse(saved) : [];
  });
  const [trainingTokens, setTrainingTokens] = useState<Token[]>([]);
  const [smsLog, setSmsLog] = useState<SMSMessage[]>(() => {
    const saved = localStorage.getItem(SMS_LOG_STORAGE_KEY);
    return saved ? JSON.parse(saved).map((s: any) => ({ ...s, timestamp: new Date(s.timestamp) })) : [];
  });
  
  const [locations, setLocations] = useState<ServiceLocation[]>(() => {
    const saved = localStorage.getItem(LOCATIONS_STORAGE_KEY);
    if (!saved) return INITIAL_LOCATIONS;
    const parsed = JSON.parse(saved);
    const combined = [...INITIAL_LOCATIONS];
    parsed.forEach((loc: ServiceLocation) => {
        if (!combined.some(l => l.id === loc.id)) combined.push(loc);
    });
    return combined;
  });

  const [currentRole, setRole] = useState<'citizen' | 'staff' | 'display' | null>(null);
  const [selectedLocationId, setLocationId] = useState<string | null>(null);
  const [language, setLanguage] = useState<Language>('en');
  const [selectedVoice, setSelectedVoice] = useState<VoiceName>(() => {
    const saved = localStorage.getItem(VOICE_STORAGE_KEY);
    return (saved as VoiceName) || 'Kore';
  });
  const [isVoiceEnabled, setVoiceEnabledState] = useState<boolean>(() => {
    const saved = localStorage.getItem(VOICE_ENABLED_KEY);
    return saved === null ? true : saved === 'true';
  });
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isTrainingMode, setIsTrainingMode] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);

  const effectiveTokens = useMemo(() => isTrainingMode ? trainingTokens : tokens, [isTrainingMode, trainingTokens, tokens]);
  const activeToken = useMemo(() => effectiveTokens.find(t => t.locationId === selectedLocationId && t.status === TokenStatus.CALLING) || null, [effectiveTokens, selectedLocationId]);

  const liveLocations = useMemo(() => {
    return locations.map(loc => ({
      ...loc,
      currentQueueSize: effectiveTokens.filter(t => t.locationId === loc.id && t.status === TokenStatus.WAITING).length
    }));
  }, [locations, effectiveTokens]);

  const t = useCallback((key: keyof typeof translations['en'], params?: Record<string, string | number>) => {
    let str = (translations[language] as any)[key] || (translations['en'] as any)[key] || key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        str = str.replace(`{${k}}`, String(v));
      });
    }
    return str;
  }, [language]);

  const syncPendingTokens = useCallback(async () => {
    const pending = tokens.some(t => t.syncStatus === 'pending');
    if (!pending || !isOnline) return;

    setIsSyncing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setTokens(prev => prev.map(t => 
      t.syncStatus === 'pending' ? { ...t, syncStatus: 'synced' as SyncStatus } : t
    ));
    setIsSyncing(false);
  }, [tokens, isOnline]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      syncPendingTokens();
    };
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [syncPendingTokens]);

  const setVoiceEnabled = useCallback((enabled: boolean) => {
    setVoiceEnabledState(enabled);
    localStorage.setItem(VOICE_ENABLED_KEY, String(enabled));
  }, []);

  const speakNotification = useCallback(async (text: string) => {
    if (!isVoiceEnabled || !isOnline) return;
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: selectedVoice },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
        const outputAudioContext = new AudioContextClass({ sampleRate: 24000 });
        
        if (outputAudioContext.state === 'suspended') {
            await outputAudioContext.resume();
        }

        const audioBuffer = await decodeAudioData(
          decodeBase64(base64Audio),
          outputAudioContext,
          24000,
          1,
        );
        const source = outputAudioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(outputAudioContext.destination);
        source.start();
      }
    } catch (error) {
      console.error("TTS Error:", error);
    }
  }, [selectedVoice, isVoiceEnabled, isOnline]);

  const addToken = useCallback((name: string, locationId: string, phone?: string, isWalkIn = false, notifySms = false) => {
    const loc = locations.find(l => l.id === locationId);
    if (loc && !isLocationOpen(loc)) return;

    const currentTokens = isTrainingMode ? trainingTokens : tokens;
    const locationTokens = currentTokens.filter(t => t.locationId === locationId);
    const nextNumber = locationTokens.length + 1;
    const prefix = loc?.type === ServiceType.HOSPITAL ? 'H' : loc?.type === ServiceType.RATION ? 'R' : 'Q';

    const newToken: Token = {
      id: `token-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      locationId,
      number: nextNumber,
      prefix,
      name,
      phone,
      isWalkIn,
      status: TokenStatus.WAITING,
      timestamp: new Date(),
      estimatedWaitTime: 0,
      syncStatus: isOnline ? 'synced' : 'pending',
      notificationMethod: notifySms ? 'sms' : 'none'
    };

    if (isTrainingMode) {
      setTrainingTokens(prev => [...prev, newToken]);
    } else {
      setTokens(prev => [...prev, newToken]);
      
      if (notifySms && isOnline && phone) {
        const newSms: SMSMessage = {
          id: `sms-${Date.now()}`,
          to: phone,
          content: `OneQueue: Token ${prefix}-${nextNumber} confirmed for ${loc?.name || 'Service Center'}. Position in line: ${locationTokens.length + 1}.`,
          timestamp: new Date(),
          status: 'delivered',
          tokenNumber: `${prefix}-${nextNumber}`
        };
        setSmsLog(prev => [newSms, ...prev]);
      }
    }
  }, [tokens, trainingTokens, isOnline, isTrainingMode, locations]);

  const getPeopleAhead = useCallback((tokenId: string) => {
    const token = effectiveTokens.find(t => t.id === tokenId);
    if (!token || token.status !== TokenStatus.WAITING) return 0;
    return effectiveTokens.filter(t => 
      t.locationId === token.locationId && 
      t.status === TokenStatus.WAITING && 
      t.timestamp < token.timestamp
    ).length;
  }, [effectiveTokens]);

  const getEstimatedWait = useCallback((tokenId: string) => {
    const token = effectiveTokens.find(t => t.id === tokenId);
    if (!token) return 0;
    if (token.status === TokenStatus.CALLING) return 0;

    const loc = locations.find(l => l.id === token.locationId);
    const peopleAhead = getPeopleAhead(tokenId);
    
    const recentCompleted = effectiveTokens
      .filter(t => t.locationId === token.locationId && t.status === TokenStatus.COMPLETED && t.calledAt && t.completedAt)
      .sort((a, b) => (b.completedAt?.getTime() || 0) - (a.completedAt?.getTime() || 0))
      .slice(0, 5);

    let dynamicAvg = loc?.averageServiceTime || 10;
    if (recentCompleted.length > 0) {
      const totalDur = recentCompleted.reduce((acc, curr) => {
        const dur = (curr.completedAt!.getTime() - curr.calledAt!.getTime()) / 60000;
        return acc + dur;
      }, 0);
      dynamicAvg = totalDur / recentCompleted.length;
    }

    dynamicAvg = Math.max(1, Math.min(60, dynamicAvg));
    return Math.ceil((peopleAhead + 1) * dynamicAvg);
  }, [effectiveTokens, locations, getPeopleAhead]);

  const login = (user: User) => setCurrentUser(user);
  const logout = () => setCurrentUser(null);
  const updateUserBiometrics = (enabled: boolean) => {
    if (currentUser) setCurrentUser({ ...currentUser, isBiometricEnabled: enabled });
  };
  const updateUserProfile = (updates: Partial<User>) => {
    if (currentUser) setCurrentUser({ ...currentUser, ...updates });
  };

  const callNext = useCallback(() => {
    if (!selectedLocationId) return;
    const now = new Date();
    const updateFn = (prev: Token[]) => {
      const nextWaiting = [...prev]
        .filter(t => t.locationId === selectedLocationId && t.status === TokenStatus.WAITING)
        .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())[0];
      if (!nextWaiting) return prev;
      return prev.map(t => {
        if (t.locationId === selectedLocationId && t.status === TokenStatus.CALLING) 
          return { ...t, status: TokenStatus.COMPLETED, completedAt: now };
        if (t.id === nextWaiting.id) 
          return { ...t, status: TokenStatus.CALLING, calledAt: now };
        return t;
      });
    };
    if (isTrainingMode) setTrainingTokens(updateFn);
    else setTokens(updateFn);
  }, [selectedLocationId, isTrainingMode]);

  const pauseQueue = useCallback(() => {
    if (!selectedLocationId) return;
    setLocations(prev => prev.map(loc => loc.id === selectedLocationId ? { ...loc, isPaused: !loc.isPaused } : loc));
  }, [selectedLocationId]);

  const isLocationOpen = useCallback((loc: ServiceLocation): boolean => {
    if (!loc.openingTime || !loc.closingTime) return true;
    const now = new Date();
    const [openH, openM] = loc.openingTime.split(':').map(Number);
    const [closeH, closeM] = loc.closingTime.split(':').map(Number);
    const openDate = new Date(); openDate.setHours(openH, openM, 0);
    const closeDate = new Date(); closeDate.setHours(closeH, closeM, 0);
    return now >= openDate && now <= closeDate;
  }, []);

  const clearSMSLog = () => setSmsLog([]);
  const setLocation = (id: string | null) => setLocationId(id);
  const resetTraining = useCallback(() => {
    if (selectedLocationId) setTrainingTokens(MOCK_TOKENS(selectedLocationId));
  }, [selectedLocationId]);
  const addFoundLocation = useCallback((loc: ServiceLocation) => {
    setLocations(prev => prev.some(l => l.id === loc.id) ? prev : [...prev, loc]);
  }, []);
  const addToRecentlyViewed = useCallback((id: string) => {
    setRecentlyViewedIds(prev => [id, ...prev.filter(p => p !== id)].slice(0, 5));
  }, []);

  return (
    <QueueContext.Provider value={{
      tokens: effectiveTokens,
      locations: liveLocations,
      smsLog,
      recentlyViewedIds,
      currentRole,
      selectedLocationId,
      language,
      selectedVoice,
      isVoiceEnabled,
      isOnline,
      isSyncing,
      isTrainingMode,
      isSupportOpen,
      setIsSupportOpen,
      currentUser,
      setIsTrainingMode,
      setRole,
      setLocation,
      addFoundLocation,
      addToRecentlyViewed,
      setLanguage,
      setVoice: setSelectedVoice,
      setVoiceEnabled,
      t,
      addToken,
      callNext,
      pauseQueue,
      cancelToken: (id) => setTokens(p => p.map(t => t.id === id ? {...t, status: TokenStatus.CANCELLED} : t)),
      activeToken,
      isLocationOpen,
      clearSMSLog,
      resetTraining,
      login,
      logout,
      updateUserBiometrics,
      updateUserProfile,
      getPeopleAhead,
      getEstimatedWait,
      speakNotification,
      syncPendingTokens
    }}>
      {children}
    </QueueContext.Provider>
  );
};

export const useQueue = () => {
  const context = useContext(QueueContext);
  if (!context) throw new Error('useQueue must be used within a QueueProvider');
  return context;
};
