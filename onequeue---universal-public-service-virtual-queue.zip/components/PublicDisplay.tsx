
import React from 'react';
import { useQueue } from '../store/QueueContext';
import { TokenStatus } from '../types';
import { MonitorPlay, Clock, Users, Megaphone } from 'lucide-react';

const PublicDisplay: React.FC = () => {
  const { tokens, activeToken, locations, selectedLocationId, t } = useQueue();
  
  const location = locations.find(l => l.id === selectedLocationId);
  const waitingTokens = tokens.filter(t => t.status === TokenStatus.WAITING).slice(0, 6);

  if (!location) {
    return (
      <div className="h-full bg-slate-900 text-white flex flex-col items-center justify-center p-12 text-center">
        <MonitorPlay className="w-24 h-24 mb-6 text-indigo-500" />
        <h2 className="text-4xl font-black mb-4">{t('board_not_connected')}</h2>
      </div>
    );
  }

  return (
    <div className="h-full bg-slate-900 text-white flex flex-col overflow-hidden">
      <div className="p-8 border-b border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h2 className="text-3xl md:text-4xl font-black uppercase tracking-tight">{location.name}</h2>
          <div className="flex gap-6 mt-2">
            <div className="flex items-center gap-2 text-indigo-400">
              <Clock className="w-5 h-5" />
              <span className="font-bold text-xl">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
        </div>
        <div className="bg-indigo-600 px-8 py-3 md:py-4 rounded-3xl flex items-center gap-4 animate-pulse">
          <Megaphone className="w-6 h-6 md:w-8 md:h-8" />
          <span className="text-lg md:text-2xl font-black italic">{t('please_wait')}</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0">
        <div className="flex-1 p-8 md:p-12 flex flex-col justify-center items-center border-b lg:border-b-0 lg:border-r border-white/10 bg-white/5 relative">
          <div className="absolute top-8 left-8">
            <span className="px-6 py-2 bg-emerald-500 rounded-full text-xl md:text-2xl font-black uppercase tracking-widest">{t('now_serving_label')}</span>
          </div>
          
          {activeToken ? (
            <div className="text-center">
              <h3 className="text-[12rem] md:text-[18rem] leading-none font-black text-emerald-400 drop-shadow-2xl">
                {activeToken.prefix}-{String(activeToken.number).padStart(3, '0')}
              </h3>
              <p className="text-4xl md:text-6xl font-bold mt-4 md:mt-8 text-white uppercase tracking-wider">{activeToken.name}</p>
            </div>
          ) : (
            <div className="text-center opacity-30">
              <h3 className="text-7xl md:text-9xl font-black mb-4">--</h3>
            </div>
          )}
        </div>

        <div className="w-full lg:w-[40%] flex flex-col overflow-hidden">
          <div className="p-6 bg-slate-800/50">
            <h4 className="text-2xl font-black text-slate-400 uppercase tracking-widest">{t('next_in_line')}</h4>
          </div>
          <div className="flex-1 overflow-hidden p-6 space-y-4">
            {waitingTokens.map((token, i) => (
              <div key={token.id} className={`flex justify-between items-center p-6 rounded-[2rem] border-2 border-white/5 ${i === 0 ? 'bg-indigo-600/20 border-indigo-500 scale-105' : 'bg-white/5'}`}>
                <div className="flex items-center gap-4">
                  <span className={`text-3xl font-black ${i === 0 ? 'text-indigo-400' : 'text-slate-500'}`}>#{token.number}</span>
                  <span className="text-2xl font-bold truncate max-w-[150px]">{token.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-indigo-900 p-4 overflow-hidden relative">
        <div className="flex whitespace-nowrap animate-marquee">
          {[1, 2].map(i => (
            <span key={i} className="text-lg font-bold text-indigo-200 px-12">
              {t('ticker_text')}
            </span>
          ))}
        </div>
      </div>
      
      <style>{`
        @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
        .animate-marquee { animation: marquee 30s linear infinite; }
      `}</style>
    </div>
  );
};

export default PublicDisplay;
