
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { UserPlus, Play, Pause, Clock, ArrowRight, TrendingUp, Zap, BarChart3, ShieldCheck, Landmark, Download, LogOut, Smartphone, Headphones, Volume2, VolumeX, AudioLines, GraduationCap, Beaker, RefreshCcw, AlertTriangle, ShieldAlert } from 'lucide-react';
import { useQueue } from '../store/QueueContext';
import { TokenStatus } from '../types';

const SoundWave: React.FC = () => (
  <div className="flex items-center gap-1 h-6">
    {[1, 2, 3, 4, 5].map((i) => (
      <div
        key={i}
        className="w-1 bg-white rounded-full animate-bounce"
        style={{
          animationDuration: `${0.5 + Math.random()}s`,
          height: `${40 + Math.random() * 60}%`
        }}
      />
    ))}
  </div>
);

const StaffDashboard: React.FC = () => {
  const { 
    tokens, 
    locations, 
    selectedLocationId, 
    setLocation, 
    addToken, 
    callNext, 
    pauseQueue,
    activeToken,
    currentUser,
    logout,
    t,
    speakNotification,
    isTrainingMode,
    setIsTrainingMode,
    resetTraining,
    setIsSupportOpen
  } = useQueue();

  const [showAddModal, setShowAddModal] = useState(false);
  const [walkInName, setWalkInName] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(() => {
    const saved = localStorage.getItem('onequeue_staff_voice_enabled');
    return saved === null ? true : saved === 'true';
  });

  useEffect(() => {
    localStorage.setItem('onequeue_staff_voice_enabled', String(voiceEnabled));
  }, [voiceEnabled]);

  const effectiveLocId = currentUser?.workLocationId || selectedLocationId;
  const location = locations.find(l => l.id === effectiveLocId);

  const waitingTokens = useMemo(() => tokens.filter(t => t.locationId === effectiveLocId && t.status === TokenStatus.WAITING), [tokens, effectiveLocId]);
  const completedTokens = useMemo(() => tokens.filter(t => t.locationId === effectiveLocId && t.status === TokenStatus.COMPLETED), [tokens, effectiveLocId]);

  const handleDownload = () => {
    alert("Starting download of OneQueue Staff App for Chrome OS/Windows...");
  };

  const handleCallNext = useCallback(async () => {
    if (waitingTokens.length === 0) return;
    const nextToken = [...waitingTokens].sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())[0];
    callNext();
    if (nextToken && voiceEnabled) {
      setIsSpeaking(true);
      const msg = t('voice_staff_calling_next', { number: `${nextToken.prefix}-${nextToken.number}` });
      try {
        await speakNotification(msg);
      } finally {
        setIsSpeaking(false);
      }
    }
  }, [waitingTokens, callNext, speakNotification, t, voiceEnabled]);

  const handlePauseToggle = useCallback(async () => {
    if (!location) return;
    const wasPaused = location.isPaused;
    pauseQueue();
    if (voiceEnabled) {
      setIsSpeaking(true);
      const msg = wasPaused ? t('voice_staff_resumed') : t('voice_staff_paused');
      try {
        await speakNotification(msg);
      } finally {
        setIsSpeaking(false);
      }
    }
  }, [location, pauseQueue, speakNotification, t, voiceEnabled]);

  const toggleTrainingMode = () => {
    const newState = !isTrainingMode;
    setIsTrainingMode(newState);
    if (newState) {
      resetTraining();
    }
  };

  if (!location) {
    return (
      <div className="p-12 max-w-xl mx-auto text-center h-[80vh] flex flex-col justify-center">
        <Landmark className="w-20 h-20 text-slate-200 mx-auto mb-6" />
        <h2 className="text-3xl font-black mb-4">Facility Not Assigned</h2>
        <p className="text-slate-500 mb-8">Please login with a verified Staff ID to manage a facility.</p>
        <button onClick={logout} className="bg-rose-600 text-white px-8 py-4 rounded-2xl font-black">Login Again</button>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 bg-slate-50 min-h-screen relative">
      {/* Floating Support Button */}
      <button 
        onClick={() => setIsSupportOpen(true)}
        className="fixed bottom-10 right-10 p-5 bg-slate-900 text-white rounded-[2rem] shadow-2xl z-[60] hover:scale-110 active:scale-95 transition-all group border-4 border-white"
      >
        <Headphones className="w-7 h-7 group-hover:rotate-12 transition-transform" />
      </button>

      {isTrainingMode && (
        <div className="mb-8 p-6 bg-amber-50 border-4 border-amber-200 rounded-[3rem] shadow-lg animate-in slide-in-from-top-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-6">
            <div className="bg-amber-500 p-4 rounded-[1.5rem] text-white shadow-xl shadow-amber-100">
               <GraduationCap className="w-8 h-8" />
            </div>
            <div>
               <h3 className="text-2xl font-black text-amber-900 tracking-tight">{t('training_active')}</h3>
               <p className="text-amber-700 font-bold text-sm max-w-xl">{t('training_mode_desc')}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
             <button 
                onClick={resetTraining}
                className="bg-white text-amber-600 border-2 border-amber-200 px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-amber-100 transition-all"
             >
                <RefreshCcw className="w-4 h-4" /> {t('reset_training')}
             </button>
             <button 
                onClick={() => setIsTrainingMode(false)}
                className="bg-amber-900 text-white px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all"
             >
                Exit Practice
             </button>
          </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1 space-y-8">
          
          <div className="bg-white rounded-[3rem] p-8 border-4 border-emerald-50 shadow-xl flex flex-col md:flex-row items-center gap-8 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-10 opacity-[0.03] group-hover:rotate-12 transition-transform pointer-events-none">
               <ShieldCheck className="w-48 h-48" />
            </div>
            <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-emerald-100 shrink-0">
               <img src={currentUser?.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${currentUser?.fullName}`} alt="S" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
               <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-2xl font-black text-slate-900">{currentUser?.fullName}</h2>
                  <ShieldCheck className="w-5 h-5 text-emerald-500" />
               </div>
               <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">Staff ID: {currentUser?.employeeId || 'N/A'}</p>
               <div className="flex flex-wrap gap-2">
                 <div className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-600 px-4 py-1.5 rounded-full">
                    <Landmark className="w-4 h-4" />
                    <span className="text-[10px] font-black uppercase tracking-widest">{location.name}</span>
                 </div>
                 <button 
                    onClick={toggleTrainingMode}
                    className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full transition-all border-2 ${isTrainingMode ? 'bg-amber-500 border-amber-500 text-white' : 'bg-white border-slate-100 text-slate-400 hover:border-amber-200'}`}
                 >
                    {isTrainingMode ? <Beaker className="w-4 h-4" /> : <GraduationCap className="w-4 h-4" />}
                    <span className="text-[10px] font-black uppercase tracking-widest">{isTrainingMode ? t('sandbox') : t('practice')}</span>
                 </button>
               </div>
            </div>
            <div className="flex items-center gap-4">
               <button 
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all ${voiceEnabled ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-slate-50 border-slate-100 text-slate-400'}`}
               >
                  {voiceEnabled ? <Volume2 className="w-6 h-6 mb-1" /> : <VolumeX className="w-6 h-6 mb-1" />}
                  <span className="text-[8px] font-black uppercase tracking-widest">{t('announcements_toggle')}</span>
               </button>
               <div className="hidden md:flex flex-col gap-2">
                  <button onClick={handleDownload} className="bg-slate-900 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                     <Download className="w-4 h-4" /> Chrome App
                  </button>
               </div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
              <p className="text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">{t('waitlist')}</p>
              <p className={`text-3xl font-black ${isTrainingMode ? 'text-amber-600' : 'text-indigo-600'}`}>{waitingTokens.length}</p>
            </div>
            <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
              <p className="text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">{t('served')}</p>
              <p className="text-3xl font-black text-emerald-500">{completedTokens.length}</p>
            </div>
            <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
              <p className="text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Facility Status</p>
              <p className={`text-3xl font-black ${location.isPaused ? 'text-rose-500' : 'text-emerald-500'}`}>{location.isPaused ? 'PAUSED' : 'LIVE'}</p>
            </div>
            <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
              <p className="text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Work Desk</p>
              <p className="text-3xl font-black text-slate-900">#01</p>
            </div>
          </div>

          <div className={`rounded-[4rem] p-12 text-white shadow-2xl text-center relative overflow-hidden transition-colors duration-500 ${isTrainingMode ? 'bg-amber-600 shadow-amber-200' : 'bg-indigo-600 shadow-indigo-200'}`}>
             <div className="absolute top-10 right-12 flex items-center gap-3">
               {isSpeaking && <SoundWave />}
               <div className={`p-3 rounded-full transition-all ${isSpeaking ? 'bg-white/30 text-white' : 'bg-white/10 text-white/40'}`}>
                 <AudioLines className="w-6 h-6" />
               </div>
             </div>
             
             <div className="flex flex-col items-center mb-10">
               <span className="px-6 py-2 bg-white/20 rounded-full text-[10px] font-black uppercase tracking-widest inline-block">{t('now_serving_label')}</span>
               {isTrainingMode && (
                  <div className="mt-4 flex items-center gap-2 bg-black/20 px-4 py-1.5 rounded-full border border-white/20">
                    <ShieldAlert className="w-3 h-3" />
                    <span className="text-[8px] font-black uppercase tracking-widest">Simulation Mode Active</span>
                  </div>
               )}
             </div>

             {activeToken ? (
               <div className="animate-in zoom-in duration-500">
                  <h3 className="text-[10rem] font-black leading-none mb-4 tracking-tighter drop-shadow-2xl">{activeToken.prefix}-{String(activeToken.number).padStart(3, '0')}</h3>
                  <p className="text-3xl font-bold tracking-tight">{activeToken.name}</p>
               </div>
             ) : (
               <div className="py-12 opacity-40">
                  <Clock className="w-20 h-20 mx-auto mb-4" />
                  <p className="text-3xl font-black uppercase">{t('waiting_for_next')}</p>
               </div>
             )}
             <div className="mt-12 flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
                <button 
                  onClick={handleCallNext} 
                  disabled={waitingTokens.length === 0 || isSpeaking} 
                  className={`flex-1 bg-white py-6 rounded-3xl font-black text-xl shadow-xl hover:scale-105 transition-transform disabled:opacity-50 flex items-center justify-center gap-3 active:scale-95 ${isTrainingMode ? 'text-amber-600' : 'text-indigo-600'}`}
                >
                   <Play className="w-6 h-6" /> {t('call_next')}
                </button>
                <button 
                  onClick={handlePauseToggle} 
                  disabled={isSpeaking}
                  className={`flex-1 py-6 rounded-3xl font-black text-xl shadow-xl hover:scale-105 transition-transform flex items-center justify-center gap-3 active:scale-95 ${location.isPaused ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}
                >
                   {location.isPaused ? <><Play className="w-6 h-6" /> {t('resume_queue')}</> : <><Pause className="w-6 h-6" /> {t('pause_queue')}</>}
                </button>
             </div>
          </div>
        </div>

        <div className="w-full lg:w-[400px] space-y-8">
          <div className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-sm">
             <div className="flex items-center gap-3 mb-8">
                <BarChart3 className={`w-6 h-6 ${isTrainingMode ? 'text-amber-600' : 'text-indigo-600'}`} />
                <h4 className="font-black text-slate-900 uppercase tracking-widest">{t('analytics_title')}</h4>
             </div>
             <div className="space-y-6">
                <div className="flex items-center justify-between">
                   <p className="text-sm font-bold text-slate-500">{t('avg_speed')}</p>
                   <span className="text-xl font-black">{location.averageServiceTime} min</span>
                </div>
                <div className="flex items-center justify-between">
                   <p className="text-sm font-bold text-slate-500">{t('staff_performance')}</p>
                   <span className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-black">EXCELLENT</span>
                </div>
                <div className="h-2 bg-slate-50 rounded-full overflow-hidden">
                   <div className={`h-full w-[85%] ${isTrainingMode ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                </div>
             </div>
          </div>
          
          <div className="bg-slate-900 rounded-[3rem] p-8 text-white relative overflow-hidden">
             {isTrainingMode && (
               <div className="absolute inset-0 bg-amber-600/10 pointer-events-none border-4 border-amber-600/20 rounded-[3rem]"></div>
             )}
             <div className="flex items-center justify-between mb-6">
                <h4 className="font-black uppercase tracking-widest text-slate-500 text-xs">Upcoming Queue</h4>
                <span className={`px-2 py-1 rounded-md text-[10px] font-black ${isTrainingMode ? 'bg-amber-500/20 text-amber-400' : 'bg-white/10 text-white'}`}>{waitingTokens.length} Left</span>
             </div>
             <div className="space-y-4 max-h-[300px] overflow-y-auto no-scrollbar">
                {waitingTokens.map(token => (
                   <div key={token.id} className="flex items-center justify-between bg-white/5 p-4 rounded-2xl border border-white/5 group transition-colors">
                      <div className="flex items-center gap-4">
                         <span className={`font-black ${isTrainingMode ? 'text-amber-400' : 'text-indigo-400'}`}>{token.prefix}-{token.number}</span>
                         <span className="font-bold text-sm truncate max-w-[120px]">{token.name}</span>
                      </div>
                      <span className="text-[10px] font-black opacity-40">{token.estimatedWaitTime}m</span>
                   </div>
                ))}
                {waitingTokens.length === 0 && <p className="text-center text-slate-600 py-10 font-bold uppercase tracking-widest text-[10px]">No citizens waiting</p>}
             </div>
          </div>

          <button 
             onClick={() => setShowAddModal(true)}
             className={`w-full bg-white border-2 border-slate-100 p-8 rounded-[3rem] flex items-center justify-between group transition-all shadow-sm ${isTrainingMode ? 'hover:border-amber-200' : 'hover:border-indigo-200'}`}
          >
             <div className="flex items-center gap-4">
                <div className={`p-4 rounded-2xl group-hover:scale-110 transition-transform ${isTrainingMode ? 'bg-amber-50 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                   <UserPlus className="w-7 h-7" />
                </div>
                <div className="text-left">
                   <p className="font-black text-slate-900">{t('add_walkin')}</p>
                   <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Manual Override</p>
                </div>
             </div>
             <ArrowRight className="w-5 h-5 text-slate-300 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
          <div className="bg-white w-full max-w-md rounded-[3rem] p-10 animate-in zoom-in-95">
            <div className="flex items-center gap-4 mb-8">
               <div className={`p-3 rounded-xl ${isTrainingMode ? 'bg-amber-50 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                  <UserPlus className="w-6 h-6" />
               </div>
               <h3 className="text-3xl font-black tracking-tight">{t('add_walkin')}</h3>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); addToken(walkInName, location.id); setShowAddModal(false); setWalkInName(''); }} className="space-y-6">
              <div className="space-y-2">
                 <label className="text-[10px] font-black uppercase text-slate-400 ml-4 tracking-widest">Full Name</label>
                 <input required type="text" value={walkInName} onChange={(e) => setWalkInName(e.target.value)} placeholder="e.g. Anand V." className={`w-full py-5 px-8 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold outline-none focus:bg-white transition-all ${isTrainingMode ? 'focus:border-amber-500' : 'focus:border-indigo-500'}`} />
              </div>
              <div className="flex gap-4">
                <button type="button" onClick={() => setShowAddModal(false)} className="flex-1 py-5 font-black text-slate-400 uppercase tracking-widest text-xs hover:text-rose-500 transition-colors">Cancel</button>
                <button type="submit" className={`flex-1 py-5 text-white rounded-2xl font-black shadow-xl active:scale-95 transition-all ${isTrainingMode ? 'bg-amber-600 hover:bg-amber-700' : 'bg-indigo-600 hover:bg-indigo-700'}`}>Add Token</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffDashboard;
