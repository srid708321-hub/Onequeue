
import React, { useState, useEffect } from 'react';
import { Sparkles, Info, RefreshCw } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { useQueue } from '../store/QueueContext';

const AIInsights: React.FC = () => {
  const { tokens, locations, selectedLocationId, language, getPeopleAhead, getEstimatedWait, t } = useQueue();
  const [insight, setInsight] = useState<string>('Analyzing real-time patterns...');
  const [loading, setLoading] = useState(false);

  const myToken = tokens.find(t => (t.status === 'Waiting' || t.status === 'Now Serving') && !t.id.startsWith('sim') && !t.id.startsWith('mock'));
  const location = locations.find(l => l.id === (myToken?.locationId || selectedLocationId));

  const fetchInsight = async () => {
    if (!location) return;
    setLoading(true);
    try {
      const peopleAhead = myToken ? getPeopleAhead(myToken.id) : tokens.filter(t => t.locationId === location.id && t.status === 'Waiting').length;
      const waitTime = myToken ? getEstimatedWait(myToken.id) : (peopleAhead + 1) * location.averageServiceTime;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemInstruction = `
        You are NEGU's insight engine.
        Analyze real-time data for ${location.name} (${location.type}).
        User Position: ${peopleAhead} ahead, ~${waitTime}m wait.
        Task: Provide a 2-sentence empathetic advice in ${language === 'ta' ? 'Tamil' : language === 'hi' ? 'Hindi' : 'English'}.
        If wait is long, suggest patience. If short, suggest alertness.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: "Analyze current queue status.",
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.5,
        }
      });

      setInsight(response.text || 'Registry sync successful. Queue moving normally.');
    } catch (err) {
      console.error("NEGU Insight Error:", err);
      setInsight('Analyzing latest registry data... Please keep your active token screen ready.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInsight();
  }, [tokens.length, language, selectedLocationId]);

  return (
    <div className="bg-slate-900 p-10 rounded-[4rem] text-white shadow-2xl relative overflow-hidden border border-white/5 animate-in fade-in slide-in-from-top-4 duration-1000">
      <div className="absolute top-0 right-0 p-6 opacity-10 pointer-events-none">
        <Sparkles className="w-24 h-24" />
      </div>
      
      <div className="flex items-center gap-4 mb-6">
        <div className="bg-indigo-500 p-3 rounded-2xl">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <div>
           <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-400 mb-1">{t('negu_ai')}</h4>
           <p className="text-[10px] font-bold text-slate-500">Live AI Analysis</p>
        </div>
        {loading && <RefreshCw className="w-5 h-5 animate-spin ml-auto text-indigo-400" />}
      </div>
      
      <p className="text-xl md:text-2xl text-slate-100 leading-relaxed font-medium italic">
        "{insight}"
      </p>

      <div className="mt-8 flex items-center justify-between">
         <div className="flex items-center gap-3 text-[10px] font-black text-slate-500 bg-white/5 px-5 py-3 rounded-full border border-white/5 uppercase tracking-widest">
            <Info className="w-4 h-4 text-indigo-500" />
            {t('negu_assist')} Insights
         </div>
         <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-4 py-2 rounded-full border border-emerald-500/20">Sync Level 1</span>
      </div>
    </div>
  );
};

export default AIInsights;
