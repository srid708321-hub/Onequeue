
import React from 'react';
import { Globe, Smartphone, QrCode, CheckCircle2, ArrowRight, Zap } from 'lucide-react';
import { useQueue } from '../store/QueueContext';

const TutorialView: React.FC = () => {
  const { t, setIsSupportOpen } = useQueue();

  const steps = [
    {
      icon: <Search className="w-8 h-8" />,
      title: t('phase1_title'),
      desc: t('phase1_desc'),
      color: 'bg-indigo-50 text-indigo-600'
    },
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: t('phase2_title'),
      desc: t('phase2_desc'),
      color: 'bg-emerald-50 text-emerald-600'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: t('phase3_title'),
      desc: t('phase3_desc'),
      color: 'bg-amber-50 text-amber-600'
    },
    {
      icon: <CheckCircle2 className="w-8 h-8" />,
      title: t('phase4_title'),
      desc: t('phase4_desc'),
      color: 'bg-rose-50 text-rose-600'
    }
  ];

  return (
    <div className="p-6 max-w-5xl mx-auto pb-40 animate-in fade-in slide-in-from-bottom-8 duration-700">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center gap-6 mb-16">
        <div className="bg-slate-900 p-6 rounded-[2rem] text-white shadow-2xl">
          <Globe className="w-12 h-12" />
        </div>
        <div>
          <h2 className="text-5xl font-black text-slate-900 tracking-tighter mb-2">{t('tutorial_title')}</h2>
          <p className="text-slate-500 font-bold text-xl">{t('tutorial_desc')}</p>
        </div>
      </div>

      {/* Process Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        {steps.map((step, idx) => (
          <div key={idx} className="bg-white p-10 rounded-[3rem] border-4 border-slate-50 shadow-sm hover:shadow-xl transition-all group">
            <div className={`p-5 rounded-2xl mb-8 inline-block transition-transform group-hover:rotate-12 ${step.color}`}>
              {step.icon}
            </div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 mb-2">Step 0{idx + 1}</h4>
            <h5 className="text-2xl font-black text-slate-900 mb-3">{step.title}</h5>
            <p className="text-slate-500 font-medium leading-relaxed text-sm">{step.desc}</p>
          </div>
        ))}
      </div>

      {/* Detailed Instruction Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-[4rem] p-12 border-4 border-indigo-50 shadow-2xl relative overflow-hidden group">
          <div className="absolute -top-10 -right-10 opacity-5 pointer-events-none group-hover:rotate-12 transition-transform">
            <QrCode className="w-64 h-64" />
          </div>
          
          <div className="flex items-center gap-4 mb-8">
            <div className="bg-indigo-600 p-4 rounded-2xl text-white shadow-lg">
              <QrCode className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-black text-slate-900">Scanning for Entry</h3>
          </div>
          
          <ul className="space-y-6">
            <li className="flex items-start gap-4">
              <div className="mt-1 p-1 bg-indigo-50 text-indigo-600 rounded-full"><CheckCircle2 className="w-4 h-4" /></div>
              <p className="text-slate-600 font-medium">Locate the official OneQueue standee at the entrance of the hospital or office.</p>
            </li>
            <li className="flex items-start gap-4">
              <div className="mt-1 p-1 bg-indigo-50 text-indigo-600 rounded-full"><CheckCircle2 className="w-4 h-4" /></div>
              <p className="text-slate-600 font-medium">Use your phone camera or the Scan button in the Explore tab to read the code.</p>
            </li>
            <li className="flex items-start gap-4">
              <div className="mt-1 p-1 bg-indigo-50 text-indigo-600 rounded-full"><CheckCircle2 className="w-4 h-4" /></div>
              <p className="text-slate-600 font-medium">Verify the facility name and tap 'Join Queue' to receive your digital token instantly.</p>
            </li>
          </ul>
        </div>

        <div className="bg-slate-900 rounded-[4rem] p-12 text-white shadow-2xl relative overflow-hidden group">
          <div className="absolute -top-10 -right-10 opacity-5 pointer-events-none group-hover:-rotate-12 transition-transform">
            <Smartphone className="w-64 h-64" />
          </div>

          <div className="flex items-center gap-4 mb-8">
            <div className="bg-emerald-500 p-4 rounded-2xl text-white shadow-lg">
              <Smartphone className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-black">Managing Your Turn</h3>
          </div>

          <ul className="space-y-6">
            <li className="flex items-start gap-4">
              <div className="mt-1 p-1 bg-white/10 text-emerald-400 rounded-full"><CheckCircle2 className="w-4 h-4" /></div>
              <p className="text-slate-300 font-medium">Track your position live in the 'Active' tab. You'll see exactly how many people are ahead.</p>
            </li>
            <li className="flex items-start gap-4">
              <div className="mt-1 p-1 bg-white/10 text-emerald-400 rounded-full"><CheckCircle2 className="w-4 h-4" /></div>
              <p className="text-slate-300 font-medium">Wait anywhere—in your car, at a nearby shop, or in the seating area. We'll alert you via SMS.</p>
            </li>
            <li className="flex items-start gap-4">
              <div className="mt-1 p-1 bg-white/10 text-emerald-400 rounded-full"><CheckCircle2 className="w-4 h-4" /></div>
              <p className="text-slate-300 font-medium">When the screen turns green and says 'Now Serving', head straight to your assigned counter.</p>
            </li>
          </ul>
        </div>
      </div>

      {/* Support Footer */}
      <div className="mt-16 bg-slate-50 border-4 border-slate-100 p-12 rounded-[4rem] text-center">
        <h4 className="text-xl font-black text-slate-900 mb-4">Still need assistance?</h4>
        <p className="text-slate-500 font-medium mb-8 max-w-xl mx-auto">Our AI-powered assistant is available 24/7 to help you with any questions about the OneQueue system.</p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button 
            onClick={() => setIsSupportOpen(true)}
            className="bg-indigo-600 text-white px-10 py-5 rounded-[2rem] font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-xl hover:scale-105 transition-all"
          >
            Open AI Chat <ArrowRight className="w-4 h-4" />
          </button>
          <div className="px-6 py-3 bg-white rounded-full border border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-400">
            Available in 7+ Languages
          </div>
        </div>
      </div>
    </div>
  );
};

const Search = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
    <circle cx="11" cy="11" r="8" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35" />
  </svg>
);

export default TutorialView;
