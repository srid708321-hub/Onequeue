
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Users, Layers, LayoutDashboard, MonitorPlay, Globe, LogIn, LogOut, User as UserIcon, Mail, Database, ShieldCheck } from 'lucide-react';
import { useQueue } from '../store/QueueContext';
import { Language } from '../store/translations';

const Navbar: React.FC = () => {
  const { currentRole, language, setLanguage, t, currentUser, logout, isOnline } = useQueue();
  const location = useLocation();
  const navigate = useNavigate();

  const getRoleLabel = () => {
    switch(currentRole) {
      case 'staff': return t('staff_portal');
      case 'display': return t('public_board');
      case 'citizen': return t('citizen_app');
      default: return t('app_name');
    }
  };

  const navItems = [
    { to: '/citizen', icon: <Layers className="w-5 h-5" />, label: t('nav_citizen'), role: 'citizen' },
    { to: '/staff', icon: <LayoutDashboard className="w-5 h-5" />, label: t('nav_staff'), role: 'staff' },
    { to: '/display', icon: <MonitorPlay className="w-5 h-5" />, label: t('nav_display'), role: 'display' },
  ];

  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'EN' },
    { code: 'hi', label: 'HI' },
    { code: 'ta', label: 'TA' },
    { code: 'ml', label: 'ML' },
    { code: 'bn', label: 'BN' },
    { code: 'ur', label: 'UR' },
    { code: 'es', label: 'ES' },
  ];

  return (
    <nav className="bg-white border-b border-slate-100 px-6 py-4 flex flex-col md:flex-row items-center justify-between sticky top-0 z-50 gap-4">
      <div className="flex items-center justify-between w-full md:w-auto gap-4">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="bg-indigo-600 p-2 rounded-xl text-white group-hover:rotate-12 transition-transform">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-none">OneQueue</h1>
            <span className="text-[10px] uppercase font-bold text-indigo-500 tracking-widest">{getRoleLabel()}</span>
          </div>
        </Link>
        
        {/* Gov Status Badge */}
        <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-100">
           <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-amber-500'} animate-pulse`}></div>
           <span className="text-[8px] font-black uppercase text-slate-400 tracking-widest">{t('gov_cloud_connected')}</span>
        </div>
      </div>

      <div className="hidden md:flex items-center gap-1 bg-slate-50 p-1 rounded-full border border-slate-100">
        {navItems.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
              location.pathname.startsWith(item.to)
                ? 'bg-white text-indigo-600 shadow-sm border border-slate-200'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {item.icon}
            {item.label}
          </Link>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <div className="hidden xl:flex items-center gap-2 bg-slate-100 rounded-full px-3 py-1.5 border border-slate-200">
          <Globe className="w-4 h-4 text-slate-400" />
          <div className="flex gap-1">
            {languages.map(lang => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase transition-all ${
                  language === lang.code 
                    ? 'bg-indigo-600 text-white' 
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {lang.label}
              </button>
            ))}
          </div>
        </div>
        
        {currentUser ? (
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="flex items-center justify-end gap-1 mb-0.5">
                 <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest leading-none">{currentUser.fullName}</p>
                 {currentUser.isVerified && <ShieldCheck className="w-3 h-3 text-emerald-500" />}
              </div>
              {currentUser.email && (
                <p className="text-[8px] font-bold text-slate-400 truncate max-w-[120px]">{currentUser.email}</p>
              )}
              <button onClick={logout} className="text-[8px] font-black text-rose-500 uppercase tracking-widest hover:underline block mt-1">{t('logout')}</button>
            </div>
            <div className="w-10 h-10 rounded-full bg-indigo-50 border-2 border-indigo-100 flex items-center justify-center text-indigo-600 overflow-hidden relative group">
              {currentUser.avatar ? (
                <img src={currentUser.avatar} alt="P" className="w-full h-full object-cover" />
              ) : (
                <UserIcon className="w-5 h-5" />
              )}
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer md:hidden" onClick={logout}>
                <LogOut className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        ) : (
          <button 
            onClick={() => navigate('/auth')}
            className="bg-slate-900 text-white px-5 py-2 rounded-full font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-black transition-all"
          >
            <LogIn className="w-3 h-3" /> {t('login')}
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
