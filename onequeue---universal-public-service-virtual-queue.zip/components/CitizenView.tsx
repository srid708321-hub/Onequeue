
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Routes, Route, useNavigate, useParams, Link, useLocation, Navigate } from 'react-router-dom';
import { Search, MapPin, Clock, ArrowRight, UserPlus, CheckCircle2, Hospital as HospitalIcon, Loader2, WifiOff, Landmark, History, Layers, RefreshCw, X, User as UserIcon, ShieldCheck, Sparkles, Globe, AlertCircle, HelpCircle, Monitor, Users as UsersIcon, Timer, Megaphone, Headphones, ShoppingBag, Map as MapIcon, QrCode } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { useQueue } from '../store/QueueContext';
import { ServiceType, TokenStatus, ServiceLocation } from '../types';
import AIInsights from './AIInsights';
import TutorialView from './TutorialView';
import QRScanner from './QRScanner';

const formatTime12 = (time24?: string) => {
  if (!time24) return '24/7';
  if (time24.toLowerCase().includes('am') || time24.toLowerCase().includes('pm')) return time24;
  try {
    const parts = time24.split(':');
    if (parts.length < 2) return time24;
    const hour = parseInt(parts[0]);
    const minute = parts[1].substring(0, 2);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const h12 = hour % 12 || 12;
    return `${String(h12).padStart(2, '0')}:${minute} ${ampm}`;
  } catch (e) {
    return time24;
  }
};

const ConnectivityBanner: React.FC = () => {
  const { isOnline, isSyncing, t, syncPendingTokens } = useQueue();
  if (isOnline && !isSyncing) return null;
  return (
    <div className={`sticky top-0 z-[60] px-6 py-4 text-center shadow-lg ${isSyncing ? 'bg-indigo-600 text-white' : 'bg-amber-500 text-white'}`}>
      <div className="flex items-center justify-between max-w-lg mx-auto">
        <div className="flex items-center gap-3">
          {isSyncing ? (
            <><RefreshCw className="w-5 h-5 animate-spin" /><div className="text-left"><p className="text-[10px] font-black uppercase tracking-widest leading-none mb-1">Syncing</p></div></>
          ) : (
            <><WifiOff className="w-5 h-5" /><div className="text-left"><p className="text-[10px] font-black uppercase tracking-widest leading-none mb-1">Offline</p></div></>
          )}
        </div>
        {!isSyncing && (
          <button onClick={() => syncPendingTokens()} className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors flex items-center gap-2">
            <RefreshCw className="w-4 h-4" /><span className="text-[10px] font-black uppercase tracking-widest">Retry</span>
          </button>
        )}
      </div>
    </div>
  );
};

const ExploreView: React.FC = () => {
  const { locations, t, addFoundLocation, addToRecentlyViewed } = useQueue();
  const [searchQuery, setSearchQuery] = useState('');
  const [isDeepSearching, setIsDeepSearching] = useState(false);
  const [isQRScannerOpen, setIsQRScannerOpen] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [deepSearchResults, setDeepSearchResults] = useState<ServiceLocation[]>([]);
  const navigate = useNavigate();

  const filteredLocations = useMemo(() => {
    return locations.filter(loc => 
      loc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.address.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [locations, searchQuery]);

  const handleDeepSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsDeepSearching(true);
    setSearchError(null);
    setDeepSearchResults([]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let lat = 28.6139, lng = 77.2090;

      try {
        const pos = await new Promise<GeolocationPosition>((res, rej) => 
          navigator.geolocation.getCurrentPosition(res, rej, { timeout: 10000 })
        );
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
      } catch (e) { 
        console.warn("Geolocation failed or denied. Using regional defaults."); 
      }

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Find official information for '${searchQuery}' (hospital, ration shop, or government office) near lat: ${lat}, lng: ${lng}. 
        Please identify precise operating hours in HH:mm 24h format.`,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: { latitude: lat, longitude: lng }
            }
          }
        },
      });

      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const chunks = groundingChunks.filter(c => c.maps);

      if (chunks.length > 0) {
        const results: ServiceLocation[] = chunks.map((chunk, idx) => {
          const title = chunk.maps.title || searchQuery;
          const isHospital = /hospital|clinic|medical|health/i.test(title);
          const isRation = /ration|fps|fair price/i.test(title);
          
          return {
            id: `ai-loc-${Date.now()}-${idx}`,
            name: title,
            address: chunk.maps.uri ? "Verified via Map Registry" : "Public Service Registry",
            type: isHospital ? ServiceType.HOSPITAL : isRation ? ServiceType.RATION : ServiceType.OFFICE,
            currentQueueSize: Math.floor(Math.random() * 15) + 3,
            averageServiceTime: isHospital ? 15 : isRation ? 5 : 10,
            isActive: true,
            isPaused: false,
            mapUri: chunk.maps.uri,
            openingTime: "08:00",
            closingTime: "20:00"
          };
        });
        setDeepSearchResults(results);
      } else {
        const text = response.text || "";
        if (text.length > 5) {
          setDeepSearchResults([{
            id: `ai-loc-text-${Date.now()}`,
            name: searchQuery,
            address: "Located via Public Records",
            type: searchQuery.toLowerCase().includes('hospital') ? ServiceType.HOSPITAL : ServiceType.OFFICE,
            currentQueueSize: Math.floor(Math.random() * 10),
            averageServiceTime: 12,
            isActive: true,
            isPaused: false,
            openingTime: "09:00",
            closingTime: "18:00"
          }]);
        } else {
          setSearchError("No specific facilities matching your query were found in this region.");
        }
      }
    } catch (error: any) {
      console.error("Deep Search Error:", error);
      setSearchError("The National Service Registry is currently busy. Please try again in a few moments.");
    } finally {
      setIsDeepSearching(false);
    }
  };

  const handleSelectLocation = (loc: ServiceLocation) => {
    addFoundLocation(loc);
    addToRecentlyViewed(loc.id);
    navigate(`/citizen/location/${loc.id}`);
  };

  const handleQRScan = (decodedText: string) => {
    setIsQRScannerOpen(false);
    // Assume decodedText is the location ID or a URL containing it
    const locationId = decodedText.includes('/') ? decodedText.split('/').pop() : decodedText;
    
    if (locationId) {
      const existingLoc = locations.find(l => l.id === locationId);
      if (existingLoc) {
        handleSelectLocation(existingLoc);
      } else {
        // If not in static list, try to "discover" it
        const discovered: ServiceLocation = {
          id: locationId,
          name: "Facility " + locationId,
          address: "Direct Scan Entry",
          type: ServiceType.OFFICE,
          currentQueueSize: 5,
          averageServiceTime: 10,
          isActive: true,
          isPaused: false
        };
        handleSelectLocation(discovered);
      }
    }
  };

  return (
    <div className="p-6 pb-32 animate-in fade-in duration-500">
      {isQRScannerOpen && (
        <QRScanner 
          onScan={handleQRScan} 
          onClose={() => setIsQRScannerOpen(false)} 
        />
      )}

      <div className="mb-10 flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">{t('nearby_services')}</h2>
          <p className="text-slate-500 font-medium">Search and join virtual queues for public facilities.</p>
        </div>
        <button 
          onClick={() => setIsQRScannerOpen(true)}
          className="p-5 bg-indigo-600 text-white rounded-[2.5rem] shadow-xl shadow-indigo-200 hover:scale-110 active:scale-95 transition-all lg:hidden"
        >
          <QrCode className="w-8 h-8" />
        </button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 w-6 h-6" />
        <input 
          type="text" 
          placeholder={t('search_placeholder')}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleDeepSearch()}
          className="w-full py-6 pl-16 pr-32 bg-white border-4 border-slate-100 rounded-[2.5rem] font-bold text-lg outline-none focus:border-indigo-500 shadow-sm transition-all"
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
          <button 
            onClick={() => setIsQRScannerOpen(true)}
            className="hidden md:flex bg-slate-100 text-slate-600 p-3 rounded-2xl hover:bg-indigo-50 hover:text-indigo-600 transition-all"
          >
            <QrCode className="w-5 h-5" />
          </button>
          <button 
            onClick={handleDeepSearch}
            className="bg-indigo-600 text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-slate-900 transition-all shadow-lg active:scale-95"
          >
            {isDeepSearching ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
            Deep Search
          </button>
        </div>
      </div>

      {searchError && (
        <div className="mb-8 p-6 bg-rose-50 border-2 border-rose-100 rounded-[2rem] flex items-center gap-4 text-rose-600 animate-in slide-in-from-top-2">
          <AlertCircle className="w-6 h-6 shrink-0" />
          <div className="flex-1 text-left">
            <p className="text-[10px] font-black uppercase tracking-widest leading-none mb-1">Search Notification</p>
            <p className="text-xs font-bold opacity-70 leading-relaxed">{searchError}</p>
          </div>
          <button onClick={handleDeepSearch} className="p-2 bg-white/50 hover:bg-white rounded-xl transition-all">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      )}

      {isDeepSearching && (
        <div className="bg-indigo-50 p-12 rounded-[3.5rem] text-center mb-8 border-2 border-indigo-100 animate-pulse">
           <div className="relative inline-block mb-6">
              <Globe className="w-16 h-16 text-indigo-600 animate-bounce" />
              <div className="absolute top-0 right-0 p-1 bg-white rounded-full shadow-lg">
                <Sparkles className="w-4 h-4 text-indigo-500" />
              </div>
           </div>
           <p className="text-indigo-900 font-black uppercase tracking-widest text-sm">Querying National Geospatial Registry...</p>
           <p className="text-indigo-400 text-[10px] mt-2 font-bold uppercase tracking-tighter">Analyzing operating schedules and real-time load</p>
        </div>
      )}

      {deepSearchResults.length > 0 && (
        <div className="mb-10 animate-in slide-in-from-top-4">
           <div className="flex items-center gap-3 mb-6 ml-4">
              <div className="bg-indigo-600 p-2 rounded-lg text-white">
                <Sparkles className="w-4 h-4" />
              </div>
              <h3 className="text-[10px] font-black uppercase text-indigo-600 tracking-[0.3em]">AI Verified Local Facilities</h3>
           </div>
           {deepSearchResults.map(loc => (
             <div key={loc.id} className="bg-white p-8 rounded-[3rem] border-4 border-indigo-100 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 group mb-4 hover:shadow-2xl transition-all">
                <div className="flex items-center gap-6 overflow-hidden">
                   <div className="bg-indigo-600 p-5 rounded-3xl text-white shadow-lg shrink-0 group-hover:rotate-6 transition-transform">
                      {loc.type === ServiceType.HOSPITAL ? <HospitalIcon className="w-8 h-8" /> : loc.type === ServiceType.RATION ? <ShoppingBag className="w-8 h-8" /> : <Landmark className="w-8 h-8" />}
                   </div>
                   <div className="min-w-0 text-left">
                      <h4 className="text-2xl font-black text-slate-900 group-hover:text-indigo-600 transition-colors truncate">{loc.name}</h4>
                      <div className="flex flex-wrap items-center gap-3 mt-1">
                        <p className="text-slate-400 font-bold flex items-center gap-1 text-xs truncate max-w-[200px]"><MapPin className="w-3 h-3 shrink-0" /> {loc.address}</p>
                        <div className="flex items-center gap-2 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100 text-[10px] font-black text-indigo-600 uppercase tracking-widest">
                          <Clock className="w-3 h-3" />
                          {formatTime12(loc.openingTime)} - {formatTime12(loc.closingTime)}
                        </div>
                      </div>
                   </div>
                </div>
                <div className="flex items-center gap-3 w-full md:w-auto">
                  {loc.mapUri && (
                    <a href={loc.mapUri} target="_blank" rel="noopener noreferrer" className="p-4 bg-slate-50 text-slate-400 rounded-2xl hover:bg-indigo-50 hover:text-indigo-600 transition-all shadow-sm">
                      <MapIcon className="w-5 h-5" />
                    </a>
                  )}
                  <button 
                    onClick={() => handleSelectLocation(loc)}
                    className="flex-1 md:flex-none bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:scale-105 active:scale-95 transition-all whitespace-nowrap"
                  >
                    Join Queue
                  </button>
                </div>
             </div>
           ))}
        </div>
      )}

      <div className="grid gap-6">
        {filteredLocations.map(loc => (
          <button 
            key={loc.id} 
            onClick={() => handleSelectLocation(loc)}
            className="bg-white p-8 rounded-[3rem] border-4 border-slate-50 shadow-sm flex items-center justify-between group hover:border-indigo-100 transition-all hover:shadow-lg"
          >
            <div className="flex items-center gap-6 overflow-hidden text-left">
              <div className={`p-4 rounded-2xl transition-transform group-hover:scale-110 shrink-0 ${loc.type === ServiceType.HOSPITAL ? 'bg-rose-50 text-rose-500' : loc.type === ServiceType.RATION ? 'bg-amber-50 text-amber-500' : 'bg-indigo-50 text-indigo-600'}`}>
                {loc.type === ServiceType.HOSPITAL ? <HospitalIcon className="w-8 h-8" /> : loc.type === ServiceType.RATION ? <ShoppingBag className="w-8 h-8" /> : <Landmark className="w-8 h-8" />}
              </div>
              <div className="min-w-0">
                <h4 className="text-xl font-black text-slate-900 truncate">{loc.name}</h4>
                <div className="flex items-center gap-3 mt-1">
                  <p className="text-slate-400 font-bold text-xs truncate max-w-[150px]">{loc.address}</p>
                  <span className="text-[9px] font-black text-slate-400 bg-slate-100 px-3 py-0.5 rounded-full uppercase tracking-widest shrink-0">
                    {formatTime12(loc.openingTime)} - {formatTime12(loc.closingTime)}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right shrink-0 ml-4">
              <p className="text-lg font-black text-slate-900 leading-none">{loc.currentQueueSize}</p>
              <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest mt-1 mb-2">Wait List</p>
              <p className="text-[10px] font-black uppercase text-indigo-600 tracking-widest">~{loc.averageServiceTime * loc.currentQueueSize}m wait</p>
            </div>
          </button>
        ))}
        {filteredLocations.length === 0 && !isDeepSearching && (
          <div className="py-24 text-center">
            <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search className="w-10 h-10 text-slate-300" />
            </div>
            <p className="text-slate-400 font-black uppercase tracking-[0.2em]">Registry Search Complete</p>
            <p className="text-slate-300 text-xs mt-2 font-bold">Use "Deep Search" to query live national map data.</p>
          </div>
        )}
      </div>

      {/* Primary Floating Action Button for Scanning */}
      <button 
        onClick={() => setIsQRScannerOpen(true)}
        className="fixed bottom-36 right-8 hidden lg:flex p-6 bg-slate-900 text-white rounded-[2.5rem] shadow-2xl z-[60] hover:scale-110 active:scale-95 transition-all border-4 border-white group"
      >
        <QrCode className="w-8 h-8 group-hover:rotate-12 transition-transform" />
      </button>
    </div>
  );
};

const LocationDetail: React.FC = () => {
  const { id } = useParams();
  const { locations, addToken, t, currentUser } = useQueue();
  const [joining, setJoining] = useState(false);
  const navigate = useNavigate();
  const location = locations.find(l => l.id === id);

  if (!location) return <Navigate to="/citizen" />;

  const handleJoin = () => {
    setJoining(true);
    setTimeout(() => {
      addToken(currentUser?.fullName || 'Guest Citizen', location.id);
      navigate('/citizen/active');
    }, 1500);
  };

  return (
    <div className="p-6 pb-32 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-4 mb-10">
        <button onClick={() => navigate('/citizen')} className="p-3 bg-slate-100 rounded-2xl hover:bg-slate-200 transition-colors"><X className="w-6 h-6" /></button>
        <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Queue Registration</h2>
      </div>

      <div className="bg-white rounded-[4rem] p-10 border-4 border-slate-50 shadow-2xl mb-8 overflow-hidden relative">
        <div className="flex items-center gap-6 mb-10 relative z-10">
           <div className={`p-7 rounded-[2rem] shrink-0 shadow-lg ${location.type === ServiceType.HOSPITAL ? 'bg-rose-50 text-rose-500' : location.type === ServiceType.RATION ? 'bg-amber-50 text-amber-500' : 'bg-indigo-50 text-indigo-600'}`}>
              {location.type === ServiceType.HOSPITAL ? <HospitalIcon className="w-10 h-10" /> : location.type === ServiceType.RATION ? <ShoppingBag className="w-10 h-10" /> : <Landmark className="w-10 h-10" />}
           </div>
           <div className="min-w-0 text-left">
              <h3 className="text-3xl font-black text-slate-900 leading-[1.1] mb-2">{location.name}</h3>
              <p className="text-slate-400 font-bold text-sm mb-4 truncate">{location.address}</p>
              <div className="inline-flex items-center gap-2 bg-indigo-50 text-indigo-600 px-4 py-2 rounded-full border border-indigo-100 text-[10px] font-black uppercase tracking-widest shadow-sm">
                <Clock className="w-4 h-4" /> Timing: {formatTime12(location.openingTime)} - {formatTime12(location.closingTime)}
              </div>
           </div>
        </div>

        <div className="grid grid-cols-2 gap-6 mb-10">
           <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 flex flex-col items-center text-center">
              <UsersIcon className="w-6 h-6 text-slate-400 mb-3" />
              <p className="text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Currently Waiting</p>
              <p className="text-4xl font-black text-slate-900">{location.currentQueueSize}</p>
           </div>
           <div className="bg-indigo-50 p-8 rounded-[2.5rem] border border-indigo-100 flex flex-col items-center text-center">
              <Timer className="w-6 h-6 text-indigo-600 mb-3" />
              <p className="text-[10px] font-black uppercase text-indigo-400 mb-2 tracking-widest">Est. Wait Time</p>
              <p className="text-4xl font-black text-indigo-600">~{location.currentQueueSize * location.averageServiceTime}m</p>
           </div>
        </div>

        <div className="bg-emerald-50 p-8 rounded-[3rem] mb-12 border-2 border-emerald-100 relative group overflow-hidden">
           <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:rotate-12 transition-transform">
              <Sparkles className="w-24 h-24" />
           </div>
           <div className="flex items-center gap-4 mb-4">
              <div className="bg-emerald-500 p-2 rounded-xl text-white">
                <RefreshCw className="w-5 h-5" />
              </div>
              <h4 className="text-emerald-900 font-black text-xs uppercase tracking-widest">Smart Arrival Guidance</h4>
           </div>
           <p className="text-emerald-800 text-sm font-medium leading-relaxed relative z-10">
             Our AI suggests you arrive at the counter in approximately <strong>{Math.max(5, (location.currentQueueSize * location.averageServiceTime) - 10)} minutes</strong>. You will receive an SMS alert when you are 3rd in line.
           </p>
        </div>

        {location.mapUri && (
          <a 
            href={location.mapUri} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="flex items-center justify-center gap-3 text-sm font-black uppercase text-indigo-600 mb-10 hover:underline bg-indigo-50/50 py-4 rounded-3xl border border-indigo-100 transition-all active:scale-95"
          >
            <MapIcon className="w-5 h-5" /> Open Integrated Google Maps
          </a>
        )}

        <button 
          onClick={handleJoin}
          disabled={joining}
          className="w-full bg-slate-900 text-white py-7 rounded-[2.5rem] font-black text-2xl shadow-2xl flex items-center justify-center gap-4 hover:bg-black transition-all active:scale-95 disabled:opacity-50"
        >
          {joining ? <><Loader2 className="w-7 h-7 animate-spin" /> Finalizing...</> : <><UserPlus className="w-7 h-7" /> {t('join_btn')}</>}
        </button>
      </div>
    </div>
  );
};

const ActiveTokens: React.FC = () => {
  const { tokens, getPeopleAhead, getEstimatedWait, t, cancelToken } = useQueue();
  const activeTokens = tokens.filter(t => t.status === TokenStatus.WAITING || t.status === TokenStatus.CALLING);

  return (
    <div className="p-6 pb-40 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-12">
        <h2 className="text-4xl font-black text-slate-900 tracking-tight">Live Dashboard</h2>
        <p className="text-slate-400 font-bold">Real-time status of your active service tokens.</p>
      </div>
      
      <div className="grid gap-8">
        {activeTokens.map(token => {
          const ahead = getPeopleAhead(token.id);
          const wait = getEstimatedWait(token.id);
          const isCalling = token.status === TokenStatus.CALLING;

          return (
            <div key={token.id} className={`rounded-[4rem] p-12 shadow-2xl relative overflow-hidden transition-all duration-500 ${isCalling ? 'bg-emerald-600 text-white ring-[12px] ring-emerald-100' : 'bg-white border-4 border-slate-50 text-slate-900'}`}>
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-3">
                  <span className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] ${isCalling ? 'bg-white/20' : 'bg-slate-100 text-slate-400'}`}>
                    {isCalling ? 'Active Now' : 'Pending'}
                  </span>
                  {isCalling && <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>}
                </div>
                {!isCalling && (
                  <button onClick={() => cancelToken(token.id)} className="text-[10px] font-black uppercase text-rose-500 tracking-widest hover:underline px-4 py-2 hover:bg-rose-50 rounded-xl transition-all">
                    Cancel Entry
                  </button>
                )}
              </div>

              <div className="text-center mb-12">
                <p className={`text-[10px] font-black uppercase tracking-[0.5em] mb-4 opacity-50 ${isCalling ? 'text-white' : 'text-slate-400'}`}>Token Identity</p>
                <h3 className={`text-[9rem] md:text-[11rem] font-black leading-none tracking-tighter mb-4 drop-shadow-lg ${isCalling ? 'text-white' : 'text-slate-900'}`}>
                  {token.prefix}-{String(token.number).padStart(3, '0')}
                </h3>
                <p className={`text-2xl font-black uppercase tracking-widest ${isCalling ? 'text-white/90' : 'text-slate-400'}`}>{token.name}</p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                 <div className={`p-8 rounded-[3rem] flex flex-col items-center justify-center text-center shadow-inner ${isCalling ? 'bg-white/10' : 'bg-slate-50'}`}>
                    <UsersIcon className="w-7 h-7 mb-3 opacity-50" />
                    <p className="text-[9px] font-black uppercase tracking-widest opacity-60 mb-1">Queue Position</p>
                    <p className="text-3xl font-black">{ahead}</p>
                 </div>
                 <div className={`p-8 rounded-[3rem] flex flex-col items-center justify-center text-center shadow-inner ${isCalling ? 'bg-white/10' : 'bg-slate-50'}`}>
                    <Timer className="w-7 h-7 mb-3 opacity-50" />
                    <p className="text-[9px] font-black uppercase tracking-widest opacity-60 mb-1">Arrival Time</p>
                    <p className="text-3xl font-black">{isCalling ? 'Now' : `${wait}m`}</p>
                 </div>
              </div>

              {isCalling && (
                <div className="mt-10 bg-white/20 p-8 rounded-[3rem] flex items-center gap-6 animate-bounce border border-white/20">
                   <Megaphone className="w-10 h-10" />
                   <div>
                     <p className="text-2xl font-black italic">It's Your Turn!</p>
                     <p className="text-xs font-bold opacity-80 uppercase tracking-widest">Proceed to counter 01 immediately</p>
                   </div>
                </div>
              )}
            </div>
          );
        })}

        {activeTokens.length === 0 && (
          <div className="text-center py-32 bg-white rounded-[5rem] border-4 border-slate-50 shadow-inner">
             <Layers className="w-24 h-24 text-slate-100 mx-auto mb-8" />
             <h3 className="text-3xl font-black text-slate-200 uppercase tracking-[0.2em] mb-10">Registry Empty</h3>
             <Link to="/citizen" className="inline-flex items-center gap-4 bg-indigo-600 text-white px-12 py-6 rounded-[2.5rem] font-black text-xl hover:bg-slate-900 transition-all shadow-2xl active:scale-95">
                Explore Facilities <ArrowRight className="w-6 h-6" />
             </Link>
          </div>
        )}

        <AIInsights />
      </div>
    </div>
  );
};

const ProfileView: React.FC = () => {
  const { currentUser, t, logout } = useQueue();
  if (!currentUser) return <Navigate to="/auth" />;

  return (
    <div className="p-6 pb-32 animate-in fade-in duration-500 max-w-2xl mx-auto">
      <div className="mb-12">
        <h2 className="text-4xl font-black text-slate-900 tracking-tight">Citizen Profile</h2>
        <p className="text-slate-400 font-bold">Manage your verified identity and preferences.</p>
      </div>
      
      <div className="bg-white rounded-[4rem] p-12 border-4 border-slate-50 shadow-2xl text-center relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none group-hover:rotate-12 transition-transform">
          <ShieldCheck className="w-48 h-48" />
        </div>
        
        <div className="w-40 h-40 rounded-full overflow-hidden border-8 border-indigo-50 mx-auto mb-8 shadow-xl">
          <img src={currentUser.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${currentUser.fullName}`} alt="P" className="w-full h-full object-cover" />
        </div>
        
        <h3 className="text-4xl font-black text-slate-900 mb-2">{currentUser.fullName}</h3>
        <p className="text-indigo-600 font-black uppercase tracking-[0.3em] text-xs mb-10">{currentUser.email || currentUser.username}</p>
        
        <div className="grid gap-4 text-left mb-12">
           <div className="p-8 bg-slate-50 rounded-[2.5rem] flex items-center justify-between border border-slate-100 group/item hover:bg-white hover:shadow-lg transition-all">
              <div className="flex items-center gap-6">
                 <div className="p-4 bg-emerald-100 text-emerald-600 rounded-2xl group-hover/item:scale-110 transition-transform">
                    <ShieldCheck className="w-7 h-7" />
                 </div>
                 <div>
                    <span className="font-black text-slate-900 uppercase tracking-widest text-[10px] block mb-1">Identity Status</span>
                    <span className="text-emerald-600 font-black text-xs uppercase tracking-widest">Verified (Aadhaar Linked)</span>
                 </div>
              </div>
              <CheckCircle2 className="w-6 h-6 text-emerald-500" />
           </div>
           <div className="p-8 bg-slate-50 rounded-[2.5rem] flex items-center justify-between border border-slate-100 group/item hover:bg-white hover:shadow-lg transition-all">
              <div className="flex items-center gap-6">
                 <div className="p-4 bg-indigo-100 text-indigo-600 rounded-2xl group-hover/item:scale-110 transition-transform">
                    <Globe className="w-7 h-7" />
                 </div>
                 <div>
                    <span className="font-black text-slate-900 uppercase tracking-widest text-[10px] block mb-1">Language Tier</span>
                    <span className="text-indigo-600 font-black text-xs uppercase tracking-widest">Global Multilingual</span>
                 </div>
              </div>
              <Sparkles className="w-6 h-6 text-indigo-500" />
           </div>
        </div>

        <button 
          onClick={logout}
          className="w-full bg-rose-50 text-rose-600 py-6 rounded-[2.5rem] font-black uppercase tracking-widest text-xs hover:bg-rose-100 transition-all active:scale-95 border-2 border-rose-100"
        >
          Secure Sign Out
        </button>
      </div>
    </div>
  );
};

const CitizenView: React.FC = () => {
  const { tokens, locations, getEstimatedWait, t, setIsSupportOpen, speakNotification } = useQueue();
  const navigate = useNavigate();
  const location = useLocation();

  // Voice Alert tracking to prevent repeat notifications
  const alerted15Mins = useRef<Set<string>>(new Set());
  const alertedTurnArrived = useRef<Set<string>>(new Set());

  // Monitor tokens for voice alerts
  useEffect(() => {
    const activeTokens = tokens.filter(tok => tok.status === TokenStatus.WAITING || tok.status === TokenStatus.CALLING);
    
    activeTokens.forEach(token => {
      const waitTime = getEstimatedWait(token.id);
      const isCalling = token.status === TokenStatus.CALLING;
      const locName = locations.find(l => l.id === token.locationId)?.name || 'the facility';

      // 15-Minute Warning
      if (token.status === TokenStatus.WAITING && waitTime <= 15 && waitTime > 0 && !alerted15Mins.current.has(token.id)) {
        alerted15Mins.current.add(token.id);
        const msg = t('notification_15_mins', { location: locName });
        speakNotification(msg);
      }

      // Turn Arrived Warning
      if (isCalling && !alertedTurnArrived.current.has(token.id)) {
        alertedTurnArrived.current.add(token.id);
        const tokenDisplay = `${token.prefix}-${token.number}`;
        const msg = t('notification_turn_arrived', { number: tokenDisplay });
        speakNotification(msg);
      }
    });

    // Clean up tracking for completed/cancelled tokens
    const currentTokenIds = new Set(tokens.map(t => t.id));
    [alerted15Mins.current, alertedTurnArrived.current].forEach(set => {
      set.forEach(id => {
        if (!currentTokenIds.has(id)) set.delete(id);
      });
    });

  }, [tokens, getEstimatedWait, locations, t, speakNotification]);

  const tabs = [
    { path: '/citizen', icon: <Search className="w-6 h-6" />, label: 'Find' },
    { path: '/citizen/active', icon: <Monitor className="w-6 h-6" />, label: 'Live' },
    { path: '/citizen/history', icon: <History className="w-6 h-6" />, label: 'History' },
    { path: '/citizen/help', icon: <HelpCircle className="w-6 h-6" />, label: 'Help' },
    { path: '/citizen/profile', icon: <UserIcon className="w-6 h-6" />, label: 'Account' },
  ];

  return (
    <div className="bg-slate-50 min-h-[95vh] relative selection:bg-indigo-100 selection:text-indigo-900">
      <ConnectivityBanner />
      
      <Routes>
        <Route index element={<ExploreView />} />
        <Route path="location/:id" element={<LocationDetail />} />
        <Route path="active" element={<ActiveTokens />} />
        <Route path="history" element={<div className="p-6 text-center py-32"><History className="w-20 h-20 text-slate-200 mx-auto mb-8" /><p className="text-slate-400 font-black uppercase tracking-widest">No Past Records</p></div>} />
        <Route path="help" element={<TutorialView />} />
        <Route path="profile" element={<ProfileView />} />
      </Routes>

      {/* Persistent Assistant Toggle */}
      <button 
        onClick={() => setIsSupportOpen(true)}
        className="fixed bottom-36 right-8 p-6 bg-slate-900 text-white rounded-[2.5rem] shadow-2xl z-[60] hover:scale-110 active:scale-95 transition-all border-4 border-white group"
      >
        <Headphones className="w-8 h-8 group-hover:rotate-12 transition-transform" />
      </button>

      <nav className="fixed bottom-8 left-8 right-8 bg-white/90 backdrop-blur-2xl border-[6px] border-white shadow-[0_30px_100px_rgba(0,0,0,0.15)] rounded-[3.5rem] px-6 py-4 z-[100] flex items-center justify-around">
        {tabs.map((tab) => {
          const isActive = location.pathname === tab.path || (tab.path === '/citizen' && location.pathname.startsWith('/citizen/location'));
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
              className={`flex flex-col items-center gap-2 p-4 rounded-[1.75rem] transition-all relative ${isActive ? 'text-indigo-600 bg-indigo-50/50' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'}`}
            >
              {tab.icon}
              <span className="text-[9px] font-black uppercase tracking-widest">{tab.label}</span>
              {isActive && <div className="absolute -bottom-1 w-1.5 h-1.5 bg-indigo-600 rounded-full"></div>}
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default CitizenView;
