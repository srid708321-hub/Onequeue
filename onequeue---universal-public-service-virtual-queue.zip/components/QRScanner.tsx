
import React, { useEffect, useRef, useState } from 'react';
import { X, Camera, Zap, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Html5Qrcode } from 'html5-qrcode';
import { useQueue } from '../store/QueueContext';

interface QRScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
}

const QRScanner: React.FC<QRScannerProps> = ({ onScan, onClose }) => {
  const { t } = useQueue();
  const [error, setError] = useState<string | null>(null);
  const [hasScanned, setHasScanned] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const cameraId = "reader";

  useEffect(() => {
    const startScanner = async () => {
      try {
        const html5QrCode = new Html5Qrcode(cameraId);
        scannerRef.current = html5QrCode;

        const config = { fps: 10, qrbox: { width: 250, height: 250 } };

        await html5QrCode.start(
          { facingMode: "environment" },
          config,
          (decodedText) => {
            // Success handler
            if (!hasScanned) {
              setHasScanned(true);
              // Provide visual/haptic feedback simulation
              if (window.navigator.vibrate) window.navigator.vibrate(100);
              
              // Simulate a short delay for the "Success" animation
              setTimeout(() => {
                onScan(decodedText);
              }, 500);
            }
          },
          () => {
            // Error/Searching handler - usually ignored to prevent noise
          }
        );
      } catch (err: any) {
        console.error("Scanner Error:", err);
        setError(t('camera_permission_error'));
      }
    };

    startScanner();

    return () => {
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current.stop().catch(console.error);
      }
    };
  }, [onScan, t, hasScanned]);

  return (
    <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center animate-in fade-in duration-300">
      {/* Viewfinder area */}
      <div id={cameraId} className="w-full h-full absolute inset-0 object-cover" />
      
      {/* Overlay UI */}
      <div className="absolute inset-0 z-10 pointer-events-none border-[60px] border-black/60 md:border-[120px]">
        {/* Transparent Hole with Animated Border */}
        <div className="w-full h-full flex flex-col items-center justify-center relative">
          <div className="w-[280px] h-[280px] border-4 border-white/30 rounded-[3rem] relative overflow-hidden">
             {/* Corner Accents */}
             <div className="absolute top-0 left-0 w-10 h-10 border-t-8 border-l-8 border-indigo-500 rounded-tl-2xl"></div>
             <div className="absolute top-0 right-0 w-10 h-10 border-t-8 border-r-8 border-indigo-500 rounded-tr-2xl"></div>
             <div className="absolute bottom-0 left-0 w-10 h-10 border-b-8 border-l-8 border-indigo-500 rounded-bl-2xl"></div>
             <div className="absolute bottom-0 right-0 w-10 h-10 border-b-8 border-r-8 border-indigo-500 rounded-br-2xl"></div>
             
             {/* Scanning Line */}
             {!hasScanned && (
               <div className="absolute w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent top-0 animate-scan shadow-[0_0_15px_rgba(99,102,241,0.8)]"></div>
             )}

             {/* Success Overlay */}
             {hasScanned && (
               <div className="absolute inset-0 bg-emerald-500/20 backdrop-blur-sm flex items-center justify-center animate-in zoom-in duration-300">
                 <div className="bg-white p-4 rounded-full shadow-2xl scale-125">
                   <CheckCircle2 className="w-12 h-12 text-emerald-500" />
                 </div>
               </div>
             )}
          </div>
        </div>
      </div>

      {/* Top Controls */}
      <div className="absolute top-0 left-0 right-0 p-8 flex items-center justify-between z-20">
        <button 
          onClick={onClose}
          className="p-4 bg-white/10 backdrop-blur-md rounded-2xl text-white hover:bg-white/20 active:scale-90 transition-all pointer-events-auto"
        >
          <X className="w-6 h-6" />
        </button>
        <div className="bg-white/10 backdrop-blur-md px-6 py-3 rounded-full flex items-center gap-3">
          <Camera className="w-4 h-4 text-indigo-400" />
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white">{t('scan_qr')}</span>
        </div>
        <button 
          className="p-4 bg-white/10 backdrop-blur-md rounded-2xl text-white hover:bg-white/20 active:scale-90 transition-all pointer-events-auto"
        >
          <Zap className="w-6 h-6" />
        </button>
      </div>

      {/* Bottom Instructions */}
      <div className="absolute bottom-16 left-0 right-0 text-center px-12 z-20">
        {error ? (
          <div className="bg-rose-500/90 backdrop-blur-md p-6 rounded-[2rem] text-white flex items-center gap-4 animate-in slide-in-from-bottom-4">
            <AlertCircle className="w-8 h-8 shrink-0" />
            <p className="text-sm font-bold text-left leading-snug">{error}</p>
          </div>
        ) : (
          <div className="space-y-4 animate-in slide-in-from-bottom-4">
            <p className="text-white text-lg font-black tracking-tight drop-shadow-lg">
              {hasScanned ? 'Scan Successful' : t('scan_desc')}
            </p>
            <p className="text-white/50 text-[10px] font-black uppercase tracking-widest">
              OneQueue Smart Registry V2.5
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default QRScanner;
