
import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Volume2, VolumeX, Sparkles, Loader2, Globe, ArrowLeft, Mail, AudioLines } from 'lucide-react';
import { useQueue } from '../store/QueueContext';
import { GoogleGenAI, Chat } from '@google/genai';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

const PulseWave: React.FC = () => (
  <div className="flex items-center gap-1.5 h-8">
    {[1, 2, 3, 4, 5, 6].map((i) => (
      <div
        key={i}
        className="w-1.5 bg-indigo-500 rounded-full animate-bounce"
        style={{
          animationDuration: `${0.4 + Math.random() * 0.4}s`,
          height: `${30 + Math.random() * 70}%`
        }}
      />
    ))}
  </div>
);

const SupportCenter: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { language, t, speakNotification, currentUser } = useQueue();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const chatSessionRef = useRef<Chat | null>(null);

  // Initialize welcome message once
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{ 
        id: '1', 
        text: t('welcome_negu'), 
        sender: 'ai', 
        timestamp: new Date() 
      }]);
    }
  }, [language, t, messages.length]);

  useEffect(() => {
    if (scrollRef.current && isOpen) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isTyping, isOpen]);

  const handleSend = async (textOverride?: string) => {
    const text = textOverride || inputText;
    if (!text.trim() || isTyping) return;

    const userMsg: Message = { id: Date.now().toString(), text, sender: 'user', timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      if (!chatSessionRef.current) {
        chatSessionRef.current = ai.chats.create({
          model: 'gemini-3-flash-preview',
          config: {
            systemInstruction: `
              You are NEGU, the official 24/7 AI customer care assistant for OneQueue India. 
              OneQueue is a digital platform for virtual queues in Hospitals, Ration Shops, and Govt Offices.
              
              Rules for NEGU:
              - Name: NEGU.
              - Tone: Professional, helpful, empathetic, and concise.
              - Task: Help citizens with queue status, app features, and locations.
              - Languages: Always respond in the language the user is speaking (${language}).
              - Max length: 3 sentences per response.
              - Current Citizen: ${currentUser?.fullName || 'Guest Citizen'}.
            `,
            temperature: 0.7,
          },
        });
      }

      const response = await chatSessionRef.current.sendMessage({ message: text });
      const aiText = response.text || "I'm having a bit of trouble reaching the registry. Could you please repeat that?";
      
      const aiMsg: Message = { id: (Date.now() + 1).toString(), text: aiText, sender: 'ai', timestamp: new Date() };
      setMessages(prev => [...prev, aiMsg]);
      
      if (voiceEnabled) {
        await speakNotification(aiText);
      }
    } catch (error) {
      console.error("NEGU Chat Error:", error);
      chatSessionRef.current = null;
      
      const errorMsg: Message = { 
        id: (Date.now() + 2).toString(), 
        text: "I encountered a synchronization error with the National Service Bridge. Please check your connectivity.", 
        sender: 'ai', 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleEmailSupport = () => {
    const transcript = messages
      .map(m => `[${m.timestamp.toLocaleTimeString()}] ${m.sender.toUpperCase()}: ${m.text}`)
      .join('\n\n');
    
    const subject = encodeURIComponent(`NEGU Help - Session: ${currentUser?.fullName || 'Guest'}`);
    const body = encodeURIComponent(
      `Support Transcript:\n\n${transcript}\n\nLanguage: ${language}`
    );
    window.location.href = `mailto:care@onequeue.gov.in?subject=${subject}&body=${body}`;
  };

  const startListening = () => {
    if (isListening) return;

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      alert("Voice input is not supported on this browser. Please use Chrome or Safari.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      
      // Strict locale mapping for better recognition accuracy
      const languageMap: Record<string, string> = {
        'en': 'en-IN',
        'ta': 'ta-IN',
        'hi': 'hi-IN',
        'ml': 'ml-IN',
        'bn': 'bn-IN',
        'ur': 'ur-IN',
        'es': 'es-ES'
      };

      recognition.lang = languageMap[language] || 'en-IN';
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript && transcript.trim()) {
          handleSend(transcript.trim());
        }
      };

      recognition.onspeechend = () => {
        recognition.stop();
      };

      recognition.onerror = (event: any) => {
        console.error("Speech Recognition Error:", event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          alert("Microphone access was denied. Please check your browser settings and allow microphone access for OneQueue.");
        } else if (event.error === 'no-speech') {
          // No alert needed for "no-speech", just reset
          console.debug("No speech detected");
        } else {
          console.error("Speech error occurred:", event.error);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.error("Failed to start recognition:", err);
      setIsListening(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[999] flex flex-col bg-white animate-in slide-in-from-bottom duration-500 overflow-hidden">
      {/* Header */}
      <div className="bg-slate-900 text-white p-6 flex items-center justify-between shadow-2xl relative z-10">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-3 bg-white/10 hover:bg-white/20 rounded-2xl transition-all">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="relative">
            <div className="bg-indigo-600 p-3.5 rounded-2xl shadow-lg ring-2 ring-indigo-400">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-slate-900 rounded-full"></div>
          </div>
          <div>
            <h3 className="text-xl font-black tracking-tight">{t('negu_assist')}</h3>
            <div className="flex items-center gap-2">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">{t('smart_support')}</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleEmailSupport} className="p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-all text-slate-400 hover:text-white">
            <Mail className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setVoiceEnabled(!voiceEnabled)} 
            className={`p-3 rounded-xl transition-all ${voiceEnabled ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500'}`}
          >
            {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-8 bg-slate-50 no-scrollbar">
        <div className="text-center py-4 mb-4">
          <div className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full border border-slate-100 shadow-sm mb-2">
            <Globe className="w-3.5 h-3.5 text-indigo-500" />
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{t('multilingual_active')}</span>
          </div>
          <p className="text-[9px] text-slate-300 font-black uppercase tracking-widest leading-none">{t('negu_desc')}</p>
        </div>

        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
            <div className={`max-w-[85%] p-6 rounded-[2.5rem] shadow-sm relative group ${
              msg.sender === 'user' 
                ? 'bg-slate-900 text-white rounded-tr-none' 
                : 'bg-white text-slate-900 rounded-tl-none border border-slate-100'
            }`}>
              <p className="font-bold text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              <div className={`text-[8px] mt-3 font-black uppercase tracking-[0.2em] flex items-center gap-2 ${msg.sender === 'user' ? 'text-white/30 justify-end' : 'text-slate-300'}`}>
                {msg.sender === 'ai' && <Sparkles className="w-3 h-3 text-indigo-400" />}
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start animate-in slide-in-from-left-4 duration-500">
            <div className="bg-white p-6 rounded-[2.5rem] rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-4">
               <div className="flex gap-1.5">
                  <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
               </div>
               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">NEGU Thinking</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Box */}
      <div className="p-6 bg-white border-t border-slate-100 pb-10 shadow-[0_-10px_40px_rgba(0,0,0,0.02)]">
        <div className="flex items-center gap-4">
          <div className="relative flex-1 group">
            <input 
              type="text" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={t('type_question')}
              disabled={isTyping}
              className="w-full bg-slate-50 border-4 border-slate-50 rounded-[2rem] py-6 pl-8 pr-20 font-bold outline-none focus:border-indigo-500 focus:bg-white focus:shadow-xl transition-all disabled:opacity-50"
            />
            <button 
              onClick={() => handleSend()}
              disabled={!inputText.trim() || isTyping}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-4 bg-slate-900 text-white rounded-2xl hover:bg-indigo-600 disabled:bg-slate-100 disabled:text-slate-300 transition-all shadow-xl active:scale-95"
            >
              {isTyping ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            </button>
          </div>
          <div className="relative">
            {isListening && (
              <div className="absolute -top-12 left-1/2 -translate-x-1/2">
                <PulseWave />
              </div>
            )}
            <button 
              onClick={startListening}
              disabled={isTyping}
              className={`p-6 rounded-[2rem] shadow-2xl transition-all active:scale-90 disabled:opacity-50 ${isListening ? 'bg-rose-500 text-white animate-pulse' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}
            >
              {isListening ? <MicOff className="w-7 h-7" /> : <Mic className="w-7 h-7" />}
            </button>
          </div>
        </div>
        {isListening && (
          <p className="text-center text-[10px] font-black uppercase text-rose-500 tracking-[0.3em] mt-4 animate-pulse">
            Listening for {language}...
          </p>
        )}
      </div>
    </div>
  );
};

export default SupportCenter;
