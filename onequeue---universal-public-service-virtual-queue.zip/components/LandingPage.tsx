
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, HeartPulse, ShieldCheck, ShoppingBag } from 'lucide-react';
import { useQueue } from '../store/QueueContext';

const LandingPage: React.FC = () => {
  const { t } = useQueue();
  
  return (
    <div className="p-6 md:p-12">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <span className="inline-block px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-sm font-semibold mb-6">
            {t('citizen_centric')}
          </span>
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 leading-[1.1] mb-6 whitespace-pre-line">
            {t('hero_title')}
          </h1>
          <p className="text-lg md:text-xl text-slate-500 mb-8 leading-relaxed max-w-xl">
            {t('hero_subtitle')}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Link 
              to="/citizen" 
              className="flex items-center justify-center gap-2 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
            >
              {t('get_started')} <ArrowRight className="w-5 h-5" />
            </Link>
            <Link 
              to="/staff" 
              className="flex items-center justify-center gap-2 px-8 py-4 bg-white border-2 border-slate-200 text-slate-700 rounded-2xl font-bold hover:bg-slate-50 transition-all"
            >
              {t('staff_portal_btn')}
            </Link>
          </div>
        </div>
        
        <div className="relative group">
          <div className="absolute -inset-4 bg-indigo-100 rounded-[3rem] blur-2xl opacity-50 group-hover:opacity-100 transition duration-1000"></div>
          <div className="relative grid grid-cols-2 gap-4">
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-xl border border-slate-100 transform -rotate-3 hover:rotate-0 transition-transform">
              <HeartPulse className="w-10 h-10 text-rose-500 mb-4" />
              <h3 className="text-xl font-bold mb-2">{t('hospitals_title')}</h3>
              <p className="text-slate-500 text-sm">{t('hospitals_desc')}</p>
            </div>
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-xl border border-slate-100 transform rotate-3 translate-y-8 hover:rotate-0 transition-transform">
              <ShieldCheck className="w-10 h-10 text-emerald-500 mb-4" />
              <h3 className="text-xl font-bold mb-2">{t('gov_offices_title')}</h3>
              <p className="text-slate-500 text-sm">{t('gov_offices_desc')}</p>
            </div>
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-xl border border-slate-100 transform rotate-3 hover:rotate-0 transition-transform">
              <ShoppingBag className="w-10 h-10 text-amber-500 mb-4" />
              <h3 className="text-xl font-bold mb-2">{t('ration_shops_title')}</h3>
              <p className="text-slate-500 text-sm">{t('ration_shops_desc')}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
        {[
          { phase: '1', title: t('phase1_title'), desc: t('phase1_desc') },
          { phase: '2', title: t('phase2_title'), desc: t('phase2_desc') },
          { phase: '3', title: t('phase3_title'), desc: t('phase3_desc') },
          { phase: '4', title: t('phase4_title'), desc: t('phase4_desc') },
        ].map((p, i) => (
          <div key={i} className="relative p-6 bg-slate-50 rounded-2xl border border-slate-100">
            <span className="absolute top-4 right-4 text-4xl font-black text-slate-200">0{p.phase}</span>
            <h4 className="font-bold text-slate-900 mb-2 whitespace-nowrap">{t('phase_label')} {p.phase}</h4>
            <h5 className="font-semibold text-indigo-600 text-sm md:text-lg mb-2">{p.title}</h5>
            <p className="text-slate-500 text-xs md:text-sm">{p.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LandingPage;
