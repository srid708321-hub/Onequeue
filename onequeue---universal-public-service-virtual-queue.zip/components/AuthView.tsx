
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueue } from '../store/QueueContext';
import { User as UserIcon, Lock, ShieldAlert, Loader2, ArrowRight, ShieldCheck, Landmark, Fingerprint, Users, AlertCircle, CheckCircle2, Mail, Phone, Camera, X, Sparkles, ChevronRight, Search, FileCheck, Shield, Database, LogIn, LogOut } from 'lucide-react';

const AuthView: React.FC = () => {
  const { login, setLocation, t } = useQueue();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'LOGIN' | 'ROLE_SELECT' | 'FORGOT_PASSWORD' | 'PROFILE_SETUP'>('LOGIN');
  
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });

  const [profileData, setProfileData] = useState({
    avatar: '',
    faceIdEnabled: false,
    tempUser: null as any
  });

  const handleInitialLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    setTimeout(() => {
      if (formData.username && formData.password.length >= 6) {
        setStep('ROLE_SELECT');
      } else {
        setError(t('invalid_password'));
      }
      setLoading(false);
    }, 800);
  };

  const handleGoogleLogin = () => {
    setLoading(true);
    setError(null);
    setTimeout(() => {
      setFormData({ username: 'google_user', password: 'google_password' });
      setStep('ROLE_SELECT');
      setLoading(false);
    }, 1200);
  };

  const handleRecovery = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      alert(`A secure reset link has been sent to ${formData.username}. Please check your inbox.`);
      setStep('LOGIN');
    }, 1500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileData(prev => ({ ...prev, avatar: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const selectRole = (role: 'citizen' | 'staff') => {
    setLoading(true);
    
    setTimeout(() => {
      const tempUser = role === 'citizen' ? {
        id: `citizen-${Date.now()}`,
        username: formData.username,
        fullName: formData.username.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') || 'New Citizen',
        email: `${formData.username}@example.com`,
        role: 'citizen' as const,
        isVerified: true
      } : {
        id: `staff-${Date.now()}`,
        username: formData.username,
        fullName: 'Staff Officer',
        employeeId: `ST-${Math.floor(Math.random() * 1000)}`,
        workLocationId: 'loc-1', // Default to hospital for demo
        role: 'staff' as const,
        isVerified: true
      };

      setProfileData(prev => ({
        ...prev,
        tempUser: tempUser
      }));
      setStep('PROFILE_SETUP');
      setLoading(false);
    }, 600);
  };

  const finalizeLogin = () => {
    if (!profileData.tempUser) {
      setError("Session expired. Please try again.");
      setStep('LOGIN');
      return;
    }

    const finalUser = {
      ...profileData.tempUser,
      avatar: profileData.avatar || profileData.tempUser.avatar || '',
      isBiometricEnabled: profileData.faceIdEnabled
    };
    
    login(finalUser);
    
    setTimeout(() => {
      if (finalUser.role === 'staff' && finalUser.workLocationId) {
        setLocation(finalUser.workLocationId);
        navigate('/staff');
      } else {
        navigate('/citizen');
      }
    }, 100);
  };

  // Centralized Content Logic
  const renderContent = () => {
    switch (step) {
      case 'FORGOT_PASSWORD':
        return (
          <div className="w-full max-w-md bg-white rounded-[3rem] p-10 shadow-2xl animate-in zoom-in duration-300">
            <div className="text-center mb-8">
              <div className="inline-flex p-6 bg-rose-50 text-rose-600 rounded-3xl mb-6">
                <Lock className="w-10 h-10" />
              </div>
              <h2 className="text-3xl font-black text-slate-900 mb-2">{t('account_recovery_title')}</h2>
              <p className="text-slate-500 text-sm">{t('recovery_desc')}</p>
            </div>
            <form onSubmit={handleRecovery} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-4">{t('email_phone_label')}</label>
                <div className="relative">
                  <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 w-5 h-5" />
                  <input 
                    type="text" 
                    value={formData.username}
                    onChange={(e) => setFormData({...formData, username: e.target.value})}
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-5 pl-16 pr-6 font-bold outline-none focus:border-rose-500 transition-all"
                    placeholder="rahul_s@gov.in"
                    required
                  />
                </div>
              </div>
              <button 
                type="submit" 
                className="w-full bg-rose-600 text-white py-6 rounded-3xl font-black text-xl shadow-xl flex items-center justify-center gap-3"
                disabled={loading}
              >
                {loading ? <Loader2 className="animate-spin" /> : t('send_reset_btn')}
              </button>
              <button type="button" onClick={() => setStep('LOGIN')} className="w-full text-slate-400 font-bold text-xs uppercase tracking-widest">{t('back_to_signin')}</button>
            </form>
          </div>
        );

      case 'PROFILE_SETUP':
        return (
          <div className="w-full max-w-md bg-white rounded-[3rem] p-10 shadow-2xl animate-in zoom-in duration-300 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-2 bg-indigo-600"></div>
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 mb-4 bg-emerald-50 text-emerald-600 px-4 py-1.5 rounded-full border border-emerald-100">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Access Granted</span>
              </div>
              <h2 className="text-3xl font-black text-slate-900 mb-2">{t('profile_setup_title')}</h2>
              <p className="text-slate-500 text-sm">{profileData.tempUser?.fullName}</p>
            </div>
            <div className="flex flex-col items-center mb-10">
              <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                <div className="w-32 h-32 rounded-full bg-slate-100 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden">
                  {profileData.avatar ? (
                    <img src={profileData.avatar} alt="Avatar" className="w-full h-full object-cover" />
                  ) : (
                    <UserIcon className="w-16 h-16 text-slate-300" />
                  )}
                </div>
                <div className="absolute bottom-0 right-0 bg-indigo-600 text-white p-2.5 rounded-full border-4 border-white shadow-lg group-hover:scale-110 transition-transform">
                  <Camera className="w-5 h-5" />
                </div>
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
              </div>
              <p className="mt-4 text-[10px] font-black uppercase text-indigo-600 tracking-widest">{t('upload_profile_pic')}</p>
            </div>
            <div className="space-y-4 mb-10">
              <div className={`p-6 rounded-[2rem] border-2 transition-all cursor-pointer flex items-center justify-between ${profileData.faceIdEnabled ? 'bg-indigo-50 border-indigo-200' : 'bg-slate-50 border-slate-100'}`} onClick={() => setProfileData(p => ({...p, faceIdEnabled: !p.faceIdEnabled}))}>
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl ${profileData.faceIdEnabled ? 'bg-indigo-600 text-white' : 'bg-white text-slate-400'}`}>
                    <Fingerprint className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-black text-slate-900 text-sm">{t('face_id_login_label')}</p>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{t('biometric_sec_label')}</p>
                  </div>
                </div>
                <div className={`w-12 h-6 rounded-full relative transition-all ${profileData.faceIdEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}>
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${profileData.faceIdEnabled ? 'left-7' : 'left-1'}`}></div>
                </div>
              </div>
            </div>
            <button onClick={finalizeLogin} className="w-full bg-slate-900 text-white py-6 rounded-3xl font-black text-xl shadow-xl flex items-center justify-center gap-3 group">
              {t('complete_setup_btn')} <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        );

      case 'ROLE_SELECT':
        return (
          <div className="w-full max-w-2xl animate-in fade-in duration-500">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-white mb-4 tracking-tight">Identity Registry Bridge</h2>
              <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Select Access Tier</p>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <button onClick={() => selectRole('citizen')} disabled={loading} className="bg-white p-10 rounded-[3rem] border-2 border-slate-800 hover:border-indigo-500 hover:shadow-2xl transition-all group text-center disabled:opacity-50">
                <div className="inline-flex p-6 bg-indigo-50 text-indigo-600 rounded-3xl mb-6 group-hover:scale-110 transition-transform">
                  {loading ? <Loader2 className="w-10 h-10 animate-spin" /> : <Users className="w-10 h-10" />}
                </div>
                <h3 className="text-2xl font-black text-slate-900 mb-2">{t('nav_citizen')}</h3>
                <p className="text-slate-500 text-sm">Access public services virtually</p>
              </button>
              <button onClick={() => selectRole('staff')} disabled={loading} className="bg-white p-10 rounded-[3rem] border-2 border-slate-800 hover:border-emerald-500 hover:shadow-2xl transition-all group text-center disabled:opacity-50">
                <div className="inline-flex p-6 bg-emerald-50 text-emerald-600 rounded-3xl mb-6 group-hover:scale-110 transition-transform">
                  {loading ? <Loader2 className="w-10 h-10 animate-spin" /> : <Landmark className="w-10 h-10" />}
                </div>
                <h3 className="text-2xl font-black text-slate-900 mb-2">{t('nav_staff')}</h3>
                <p className="text-slate-500 text-sm">Manage facility queues and tokens</p>
              </button>
            </div>
          </div>
        );

      default: // 'LOGIN'
        return (
          <div className="w-full max-w-md bg-white rounded-[3rem] p-10 shadow-[0_20px_80px_rgba(0,0,0,0.5)] z-10 animate-in fade-in duration-300">
            <div className="text-center mb-10">
              <div className="inline-flex items-center justify-center p-6 bg-indigo-600 rounded-[2rem] text-white shadow-xl mb-6">
                <ShieldCheck className="w-10 h-10" />
              </div>
              <h2 className="text-4xl font-black text-slate-900 mb-2 tracking-tight">National Unified Gateway</h2>
              <p className="text-slate-400 font-medium">{t('gov_portal')}</p>
            </div>
            {error && (
              <div className="bg-rose-50 border-2 border-rose-100 p-5 rounded-2xl mb-8 flex items-center gap-4 text-rose-600">
                <AlertCircle className="w-6 h-6 shrink-0" />
                <p className="text-sm font-bold">{error}</p>
              </div>
            )}
            <form onSubmit={handleInitialLogin} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-4">{t('auth_username')}</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-5 px-6 font-bold outline-none focus:border-indigo-500 transition-all"
                  placeholder="e.g. rahul_s"
                  required
                  value={formData.username}
                  onChange={e => setFormData({...formData, username: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-4">{t('master_password')}</label>
                <input 
                  type="password" 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-5 px-6 font-bold outline-none focus:border-indigo-500 transition-all"
                  placeholder="••••••••"
                  required
                  value={formData.password}
                  onChange={e => setFormData({...formData, password: e.target.value})}
                />
                <div className="text-right px-4">
                  <button type="button" onClick={() => setStep('FORGOT_PASSWORD')} className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">
                    {t('forgot_password')}
                  </button>
                </div>
              </div>
              <button type="submit" className="w-full bg-slate-900 text-white py-6 rounded-3xl font-black text-xl shadow-xl flex items-center justify-center gap-4 active:scale-95 transition-all mt-4" disabled={loading}>
                {loading ? <Loader2 className="animate-spin" /> : <> {t('next_stage')} <ArrowRight className="w-5 h-5" /></>}
              </button>
            </form>
            <div className="relative my-8">
               <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
               <div className="relative flex justify-center text-[10px] uppercase font-black tracking-widest text-slate-300"><span className="bg-white px-4">{t('or_continue_with')}</span></div>
            </div>
            <button onClick={handleGoogleLogin} disabled={loading} className="w-full bg-white border-2 border-slate-100 text-slate-700 py-5 rounded-3xl font-bold flex items-center justify-center gap-4 hover:bg-slate-50 transition-all active:scale-95 shadow-sm">
              {loading ? <Loader2 className="animate-spin w-5 h-5" /> : (
                <>
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 12-4.53z"/>
                  </svg>
                  {t('google_sign_in')}
                </>
              )}
            </button>
            <div className="mt-10 pt-8 border-t border-slate-50 text-center">
               <div className="inline-flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  <ShieldCheck className="w-3 h-3" /> Secure National Datalink (AES-256)
               </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 relative overflow-hidden selection:bg-indigo-500 selection:text-white">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-[120px]"></div>

      {/* Main Auth Content Container */}
      <div className="flex-1 flex flex-col items-center justify-center w-full z-10">
        {renderContent()}
      </div>
      
      {/* Centered Global Footer */}
      <div className="w-full text-center mt-12 mb-8 z-10">
        <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.4em] inline-block">
          OneQueue Gov-Security Infrastructure V2.5
        </p>
      </div>
    </div>
  );
};

export default AuthView;
